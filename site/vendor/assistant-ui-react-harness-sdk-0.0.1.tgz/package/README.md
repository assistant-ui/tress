# @assistant-ui/react-harness-sdk

A `useAui` thread resource over `useHarness`: maps messages, branches, edits, the queue, and cancel onto assistant-ui. Part of [harness-sdk](https://github.com/assistant-ui/harness-sdk), with `statewire` and `pinned`.

## Install

```sh
pnpm add @assistant-ui/react-harness-sdk harness-sdk statewire @assistant-ui/react react
```

## Use

```tsx
import { AuiConfig, AuiProvider } from "@assistant-ui/react";
import { HarnessThread } from "@assistant-ui/react-harness-sdk";
import { StatewireHttp } from "statewire";

const App = () => {
  const config = AuiConfig({
    thread: HarnessThread({
      transport: StatewireHttp({ url: "http://localhost:8000/threads/main" }),
    }),
  });
  return (
    <AuiProvider config={config}>
      <Chat />
    </AuiProvider>
  );
};
```

## Docs

- Get started: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/get-started/chat-app/page.mdx
- Guide: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/guides/harness/client/page.mdx
- Reference: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/reference/harness-sdk/page.mdx
- Spec: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/spec/runs-protocol/page.mdx
