import { useMemo, useRef } from "react";
import { resource, useResource, type Resource } from "@assistant-ui/tap";
import {
  ExternalThread,
  type AppendMessage,
  type FeedbackAdapter,
  type SpeechSynthesisAdapter,
} from "@assistant-ui/react";
import { forwardTransformScopes, type ClientOutput } from "@assistant-ui/store";
import { useHarness, Harness } from "harness-sdk";
import { convertMessages } from "./convert-messages";

const toSendParts = (message: AppendMessage): Harness.SendPart[] =>
  message.content.map((part) => {
    if (part.type !== "text")
      throw new Error(`harness: unsupported message part type: ${part.type}`);
    return { type: "text", text: part.text };
  });

const toQueueParts = (
  parts: readonly Harness.ReadonlyDeep<Harness.SendPart>[],
) =>
  parts.map((part) =>
    part.type === "text"
      ? { type: "text" as const, text: part.text }
      : {
          type: "file" as const,
          data: part.url,
          mimeType: part.mediaType,
          ...(part.filename !== undefined && { filename: part.filename }),
        },
  );

const useHarnessThread = ({
  speechAdapter,
  feedbackAdapter,
  ...options
}: HarnessThread.Options) => {
  const h = useHarness(options);

  const threadRef = useRef<ClientOutput<"thread"> | null>(null);
  // Rejected send: put the text back unless the user typed since.
  const restoring = (parts: Harness.SendPart[]) => () => {
    const composerApi = threadRef.current!.composer();
    if (composerApi.getState().text !== "") return;
    composerApi.setText(
      parts
        .flatMap((part) => (part.type === "text" ? [part.text] : []))
        .join("\n\n"),
    );
  };
  const send = (message: AppendMessage, behavior: "queue" | "steer") => {
    const parts = toSendParts(message);
    void h.sendMessage({ parts, behavior }).catch(restoring(parts));
  };

  const messages = useMemo(
    () => convertMessages(h.messages, h.isBusy),
    [h.messages, h.isBusy],
  );
  const thread = useResource(
    ExternalThread({
      messages,
      isRunning: h.isBusy,
      isLoading: h.isLoading,
      extras: h,
      speechAdapter,
      feedbackAdapter,
      onCancel: () => {
        void h.stop();
      },
      onEdit: (message) => {
        if (message.sourceId === null)
          throw new Error("harness: edit without a source message");
        const parts = toSendParts(message);
        void h.edit(message.sourceId, { parts }).catch(restoring(parts));
      },
      onReload: (parentId) => {
        const index = h.messages.findIndex((m) => m.id === parentId) + 1;
        const target = h.messages[index];
        if (target === undefined || target.role !== "assistant")
          throw new Error("harness: reload without an assistant message");
        void h.reload(target.id);
      },
      onRespondToToolApproval: (approval) => {
        void h.respond(approval.approvalId, {
          decision: approval.approved ? "approve" : "reject",
          ...(approval.reason !== undefined && { message: approval.reason }),
        });
      },
      branches: {
        getBranches: (messageId) =>
          h.messages.find((m) => m.id === messageId)?.siblings ?? [],
        switchToBranch: h.switchToBranch,
      },
      queue: {
        items: h.queue.map((q) => ({
          id: q.id,
          prompt: q.parts
            .flatMap((p) => (p.type === "text" ? [p.text] : []))
            .join("\n\n"),
          parts: toQueueParts(q.parts),
        })),
        steerItems: [],
        enqueue: (message) => send(message, "queue"),
        steer: (message) => send(message, "steer"),
        move: (queueItemId, placement) => {
          if (
            placement.lane !== "steer" ||
            placement.insertAfter != null ||
            placement.insertBefore != null
          )
            throw new Error(
              "harness: only unanchored steer moves are supported",
            );
          void h.steer(queueItemId);
        },
        edit: () => {
          throw new Error("harness: queue edit is not supported");
        },
        remove: (queueItemId) => {
          void h.dequeue(queueItemId);
        },
      },
    }),
  );
  threadRef.current = thread;
  return thread;
};

export const HarnessThread: Resource<
  ReturnType<typeof useHarnessThread>,
  [options: HarnessThread.Options]
> = resource(useHarnessThread);

export namespace HarnessThread {
  /** `thread.extras`: the underlying `Harness.Helpers` (subagent `follows`, `threads`, `inputRequests`, raw messages with metadata). */
  export type Extras = Harness.Helpers;
  export type Options = Harness.Options & {
    /** Speech synthesis adapter for reading assistant messages aloud. */
    speechAdapter?: SpeechSynthesisAdapter | undefined;
    /** Feedback adapter for thumbs up/down on assistant messages. */
    feedbackAdapter?: FeedbackAdapter | undefined;
  };
}

// Scope transforms are keyed by the underlying hook, not the resource wrapper.
forwardTransformScopes(
  useHarnessThread,
  ExternalThread(undefined as never).hook,
);
