import { HarnessCloud, HarnessCloudThreads } from "harness-sdk";
import { HarnessThreadList } from "./HarnessThreadList";

/**
 * `HarnessThreadList` on assistant-ui cloud: one config for the workspace's list and its threads.
 * @alpha
 */
export const HarnessCloudThreadList = ({
  threadId,
  defaultThreadId,
  onThreadIdChange,
  ...cloud
}: HarnessCloudThreadList.Options) =>
  HarnessThreadList({
    ...(threadId !== undefined && { threadId }),
    ...(defaultThreadId !== undefined && { defaultThreadId }),
    ...(onThreadIdChange !== undefined && { onThreadIdChange }),
    threads: HarnessCloudThreads(cloud),
    thread: (threadId) => HarnessCloud({ ...cloud, threadId }),
  });

/** @alpha */
export namespace HarnessCloudThreadList {
  export type Options = HarnessCloudThreads.Options &
    Omit<HarnessThreadList.Options, "threads" | "thread">;
}
