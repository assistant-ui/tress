import type {
  ExternalThreadMessage,
  MessageStatus,
  ThreadAssistantMessagePart,
  ThreadUserMessagePart,
  ToolCallMessagePart,
} from "@assistant-ui/react";
import { Harness } from "harness-sdk";

type ReadonlyMessage = Harness.ReadonlyDeep<Harness.Message>;
type ReadonlyPart = ReadonlyMessage["parts"][number];

const convertUserPart = (part: ReadonlyPart): ThreadUserMessagePart => {
  if (part.type === "text") return { type: "text", text: part.text };
  if (part.type === "file")
    return {
      type: "file",
      data: part.url,
      mimeType: part.mediaType,
      ...(part.filename !== undefined && { filename: part.filename }),
    };
  throw new Error(`harness: unsupported message part type: ${part.type}`);
};

const convertAssistantPart = (
  part: ReadonlyPart,
): ThreadAssistantMessagePart => {
  if (part.type === "tool") {
    return {
      type: "tool-call",
      toolCallId: part.toolInvocationId,
      toolName: part.toolName,
      // harness tool input is unknown-valued; the wire guarantees JSON
      args: part.input as ToolCallMessagePart["args"],
      argsText: JSON.stringify(part.input),
      result: part.output,
      ...(part.state === "pendingApproval" && {
        approval: { id: part.toolInvocationId },
      }),
    };
  }
  if (part.type === "text") return { type: "text", text: part.text };
  if (part.type === "reasoning") return { type: "reasoning", text: part.text };
  throw new Error(`harness: unsupported message part type: ${part.type}`);
};

const statusOf = (
  parts: ReadonlyMessage["parts"],
  running: boolean,
): MessageStatus => {
  if (
    parts.some(
      (part) => part.type === "tool" && part.state === "pendingApproval",
    )
  )
    return { type: "requires-action", reason: "tool-calls" };
  if (running) return { type: "running" };
  return { type: "complete", reason: "unknown" };
};

const ASSISTANT_METADATA = {
  unstable_state: null,
  unstable_annotations: [],
  unstable_data: [],
  steps: [],
  custom: {},
};

export const convertMessages = (
  messages: readonly ReadonlyMessage[],
  running: boolean,
): ExternalThreadMessage[] => {
  const last = messages.at(-1);
  const converted = messages.map((msg): ExternalThreadMessage => {
    const common = { id: msg.id, createdAt: new Date() };
    if (msg.role === "user") {
      return {
        ...common,
        role: "user",
        content: msg.parts.map(convertUserPart),
        attachments: [],
        metadata: { custom: {} },
      };
    }
    return {
      ...common,
      role: "assistant",
      content: msg.parts.map(convertAssistantPart),
      status: statusOf(msg.parts, running && msg === last),
      metadata: ASSISTANT_METADATA,
    };
  });
  if (running && last?.role !== "assistant")
    converted.push({
      id: `${last?.id ?? "root"}:pending`,
      createdAt: new Date(),
      role: "assistant",
      content: [],
      status: { type: "running" },
      metadata: ASSISTANT_METADATA,
    });
  return converted;
};
