import { usePathname, useRouter } from "next/navigation";

/**
 * Binds `HarnessThreadList`'s controlled `threadId` to the app router: `<base>` is the fresh thread, `<base>/<threadId>` an existing one.
 * @alpha
 */
export const useThreadRoute = ({
  base,
}: {
  base: string;
}): {
  threadId: string | null;
  onThreadIdChange: (threadId: string | null) => void;
} => {
  const router = useRouter();
  const pathname = usePathname();
  const threadId =
    pathname === base
      ? null
      : pathname.startsWith(`${base}/`)
        ? decodeURIComponent(pathname.slice(base.length + 1))
        : (() => {
            throw new Error(
              `harness: useThreadRoute: "${pathname}" is outside "${base}"`,
            );
          })();
  return {
    threadId,
    onThreadIdChange: (next) => {
      if (next === null) return router.push(base);
      const href = `${base}/${encodeURIComponent(next)}`;
      if (threadId === null) return router.replace(href);
      router.push(href);
    },
  };
};
