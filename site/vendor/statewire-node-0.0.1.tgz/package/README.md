# statewire-node

A statewire host over standard `Request`/`Response`: `GET|POST /stream` attaches as SSE, `POST /frames` submits frames, `storage` restores and saves the transport's `snapshot()`. Serves from `node:http` or a pinned instance. Part of [harness-sdk](https://github.com/assistant-ui/harness-sdk).

## Use

```ts
import { statewireHost } from "statewire-node";

const host = statewireHost({
  transport: (restored) => TodoHost(restored),
  storage: { load: () => store.get("snapshot"), save: (snapshot) => store.put("snapshot", snapshot) },
  onError: (error) => console.error(error),
  authorize: ({ headers }) => verify(headers["authorization"]),
});

// node:http
const response = await host.fetch(request);
```

Reference: apps/docs/app/statewire/docs/reference/statewire-bindings/page.mdx (`statewire-node`).
