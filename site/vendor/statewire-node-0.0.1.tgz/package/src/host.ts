import { resource, useResource } from "@assistant-ui/tap";
import type { ResourceElement } from "@assistant-ui/tap";
import type { Statewire } from "statewire";
import {
  StatewireSocketHost,
  clientIdFromUrl,
  textFrameOrClose,
  WS_SUBPROTOCOL,
} from "statewire/host-internal";
import type { StatewireHostInternal } from "statewire/host-internal";

export namespace StatewireNode {
  /** A JSON-safe snapshot of the transport's source state plus change notification; required of a transport served with `storage`. */
  export type DurableTransport = {
    snapshot(): unknown;
    subscribe(listener: () => void): () => void;
  };
  export type Storage = {
    /** The last saved snapshot; `undefined` or `null` before the first save. */
    load: () => Promise<unknown>;
    save: (snapshot: unknown) => Promise<void>;
  };
  export type Options = StatewireHostInternal.SocketHostOptions & {
    /** The served transport; a `(restored) => element` factory receives `storage.load()`. */
    transport:
      | ResourceElement<Statewire>
      | ((restored: unknown) => ResourceElement<Statewire>);
    /** Restores through the factory and saves `snapshot()` on a debounce, flushed on stream end and `close`. */
    storage?: Storage;
    /** Milliseconds between a commit and its save; default 1000. */
    persistDebounceMs?: number;
    /** Receives a failed `storage.save`; the snapshot is retried on the next change. Required with `storage`. */
    onError?: (error: unknown) => void;
  };
  /** One accepted WebSocket as the runtime exposes it; `onmessage` receives text frames as strings, binary frames as anything else. */
  export type Socket = StatewireHostInternal.Socket & {
    onmessage: ((event: { data: unknown }) => void) | null;
    onclose: (() => void) | null;
  };
  export type Upgrade = {
    /** The `Sec-WebSocket-Protocol` to accept. */
    protocol: typeof WS_SUBPROTOCOL;
    /** Attaches the accepted socket; call once the handshake completed. */
    attach: (socket: Socket) => void;
  };
  export type Host = {
    /** Routes `GET|POST …/stream`, `POST …/frames`; 426 for WebSocket upgrades, 404 otherwise. */
    fetch: (request: Request) => Promise<Response>;
    /** Validates a WebSocket upgrade: the accept, or a refusal (400 without `statewire.v1` or a valid `client` query parameter, 410 after `close`). */
    upgrade: (request: Request) => Promise<Response | Upgrade>;
    finish: (fin: StatewireHostInternal.Fin) => void;
    /** Flushes a pending save and disposes; later requests answer 410. */
    close: () => Promise<void>;
  };
}

const isDurable = (
  value: Statewire,
): value is Statewire & StatewireNode.DurableTransport => {
  const candidate = value as unknown as Record<string, unknown>;
  return (
    typeof candidate["snapshot"] === "function" &&
    typeof candidate["subscribe"] === "function"
  );
};

const routeOf = (request: Request): "ws" | "stream" | "frames" | null => {
  if (request.headers.get("Upgrade")?.toLowerCase() === "websocket")
    return "ws";
  const { pathname } = new URL(request.url);
  if (pathname.endsWith("/stream")) return "stream";
  if (pathname.endsWith("/frames")) return "frames";
  return null;
};

const onEnd = (
  body: ReadableStream<Uint8Array>,
  callback: () => void,
): ReadableStream<Uint8Array> => {
  const reader = body.getReader();
  return new ReadableStream({
    pull: async (controller) => {
      const { done, value } = await reader.read();
      if (done) {
        controller.close();
        callback();
        return;
      }
      controller.enqueue(value);
    },
    cancel: async (reason) => {
      await reader.cancel(reason);
      callback();
    },
  });
};

const detail = (status: number, message: string) =>
  Response.json({ detail: message }, { status });

/**
 * A statewire host over standard `Request`/`Response`: `POST /stream` and
 * `GET /stream` attach as SSE, `POST /frames` submits statement frames,
 * `upgrade` accepts `/ws` sockets from any runtime, any `authorize` in the
 * options gates every attach. With `storage`, the transport is restored
 * through the factory and its `snapshot()` saved after commits.
 */
export const statewireHost = (
  options: StatewireNode.Options,
): StatewireNode.Host => {
  const {
    transport,
    storage,
    persistDebounceMs = 1000,
    onError,
    ...socketOptions
  } = options;
  if (typeof transport === "function" && storage === undefined)
    throw new Error("statewire-node: a transport factory requires storage");
  if (storage !== undefined && onError === undefined)
    throw new Error("statewire-node: storage requires onError");

  let closed = false;
  let durable: (Statewire & StatewireNode.DurableTransport) | null = null;
  let unsubscribe: (() => void) | null = null;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let pending = Promise.resolve();

  const write = () => {
    if (durable === null) return;
    const snapshot = durable.snapshot();
    pending = pending.then(() => storage!.save(snapshot)).catch(onError);
  };
  const schedule = () => {
    timer ??= setTimeout(() => {
      timer = null;
      write();
    }, persistDebounceMs);
  };
  const flush = (force: boolean) => {
    const armed = timer !== null;
    if (timer !== null) clearTimeout(timer);
    timer = null;
    if (force || armed) write();
  };

  const mount = (element: ResourceElement<Statewire>) => {
    if (storage === undefined)
      return StatewireSocketHost(element, socketOptions);
    const Captured = resource(() => {
      const value = useResource(element);
      if (!isDurable(value))
        throw new Error(
          "statewire-node: a transport served with storage must expose snapshot() and subscribe()",
        );
      durable = value;
      return value;
    });
    const host = StatewireSocketHost(Captured(), socketOptions);
    unsubscribe = durable!.subscribe(schedule);
    return host;
  };
  const ready =
    typeof transport === "function"
      ? storage!.load().then((restored) => mount(transport(restored)))
      : Promise.resolve(mount(transport));

  return {
    fetch: async (request) => {
      if (closed) return new Response("disposed", { status: 410 });
      const route = routeOf(request);
      if (route === null) return new Response(null, { status: 404 });
      if (route === "ws")
        return new Response("websocket upgrades are not served here", {
          status: 426,
        });
      const host = await ready;
      if (route === "frames") {
        if (request.method !== "POST")
          return new Response(null, {
            status: 405,
            headers: { Allow: "POST" },
          });
        return host.frames(request);
      }
      const response = await host.stream(request);
      if (storage === undefined || response.body === null) return response;
      return new Response(
        onEnd(response.body, () => flush(false)),
        response,
      );
    },
    upgrade: async (request) => {
      if (routeOf(request) !== "ws")
        throw new Error("statewire-node: upgrade requires a WebSocket upgrade");
      if (closed) return new Response("disposed", { status: 410 });
      const offered = request.headers.get("Sec-WebSocket-Protocol") ?? "";
      if (!offered.split(",").some((token) => token.trim() === WS_SUBPROTOCOL))
        return detail(400, `${WS_SUBPROTOCOL} is required`);
      let clientId: string;
      try {
        clientId = clientIdFromUrl(request.url);
      } catch (error) {
        return detail(400, (error as Error).message);
      }
      const host = await ready;
      const headers = Object.fromEntries(request.headers);
      return {
        protocol: WS_SUBPROTOCOL,
        attach: (socket) => {
          const conn = host.connect(clientId, socket, { headers });
          if (conn === null) return;
          socket.onmessage = ({ data }) => {
            const text = textFrameOrClose(socket, data);
            if (text !== null) conn.message(text);
          };
          socket.onclose = () => {
            conn.close();
            flush(false);
          };
        },
      };
    },
    finish: (fin) => {
      void ready.then((host) => {
        if (closed) return;
        host.finish(fin);
        flush(true);
      });
    },
    close: async () => {
      if (closed) return;
      closed = true;
      const host = await ready;
      host.dispose();
      flush(true);
      unsubscribe?.();
      await pending;
    },
  };
};
