# harness-sdk

An agent thread as replicated state: `useHarness({ transport })` works like the AI SDK's `useChat`, with the thread owned by a server or an in-process transport. Part of [harness-sdk](https://github.com/assistant-ui/harness-sdk), with `statewire` and `pinned`.

## Install

```sh
pnpm add harness-sdk statewire react
```

## Use

```tsx
import { useHarness } from "harness-sdk";
import { StatewireHttp } from "statewire";

export const Thread = () => {
  const { messages, status, sendMessage, stop } = useHarness({
    transport: StatewireHttp({ url: "http://localhost:8000/threads/main" }),
  });
  return (
    <div>
      {messages.map((m) => (
        <p key={m.id}>{m.role}: {m.parts.map((p) => (p.type === "text" ? p.text : "")).join("")}</p>
      ))}
      <button onClick={() => sendMessage("hi")}>Send</button>
      {status === "streaming" && <button onClick={stop}>Stop</button>}
    </div>
  );
};
```

## Docs

- Get started: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/get-started/chat-app/page.mdx
- Guide: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/guides/harness/client/page.mdx
- Reference: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/reference/harness-sdk/page.mdx
- Spec: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/spec/runs-protocol/page.mdx
