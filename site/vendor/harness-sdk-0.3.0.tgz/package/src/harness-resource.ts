import { resource } from "@assistant-ui/tap";
import { useHarness } from "./use-harness";

export const HarnessResource = resource(useHarness);
