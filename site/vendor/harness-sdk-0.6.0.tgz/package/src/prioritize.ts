import { Output, experimental_decide, generateText } from "ai";
import type { Experimental_DecisionModel, LanguageModel } from "ai";
import type { RunManager } from "./runs";

const INSTRUCTIONS =
  "A user sent a new message while the agent is working. Decide how to handle it.";

const CRITERIA: Readonly<Record<RunManager.Mode, string>> = {
  steer:
    "The message adds to, corrects or redirects the current task. Fold it into the work in progress.",
  preempt:
    "The message makes the current work moot or is urgent. Stop the current work and handle this message now.",
  queue:
    "The message is a separate task. Handle it after the current work finishes.",
};

const textOf = (message: Readonly<Record<string, unknown>>): string => {
  const parts = message["parts"];
  return Array.isArray(parts)
    ? parts
        .flatMap((part: { type?: unknown; text?: unknown }) =>
          part?.type === "text" && typeof part.text === "string"
            ? [part.text]
            : [],
        )
        .join("\n\n")
    : "";
};

const stateOf = (req: RunManager.PrioritizeRequest) => ({
  current: req.run.messages.map(textOf),
  steering: req.run.steerQueue.map(textOf),
  queued: req.queue.map(textOf),
  message: textOf(req.message),
});

const modesOf = (queue: boolean): readonly RunManager.Mode[] =>
  queue ? ["steer", "preempt", "queue"] : ["steer", "preempt"];

const checkTimeout = (timeoutMs: number) => {
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0)
    throw new Error("prioritize: timeoutMs must be a positive number");
};

/** The request's signal, also aborted after `timeoutMs`. */
const deadline = (signal: AbortSignal, timeoutMs: number) =>
  AbortSignal.any([signal, AbortSignal.timeout(timeoutMs)]);

/** A prioritizer over a language model: one structured choice per mid-run message; a timeout steers. */
export const llmPrioritizer = ({
  model,
  timeoutMs = 1500,
  prompt,
  queue = false,
}: Prioritize.LlmOptions): RunManager.Prioritize => {
  checkTimeout(timeoutMs);
  const modes = modesOf(queue);
  const system =
    prompt ??
    [INSTRUCTIONS, ...modes.map((mode) => `- ${mode}: ${CRITERIA[mode]}`)].join(
      "\n",
    );
  return async (req) => {
    const signal = deadline(req.signal, timeoutMs);
    try {
      const { output } = await generateText({
        model,
        system,
        prompt: JSON.stringify(stateOf(req)),
        output: Output.choice({ options: [...modes] }),
        abortSignal: signal,
      });
      return output;
    } catch (error) {
      if (signal.aborted) return "steer";
      throw error;
    }
  };
};

/** A prioritizer over a decision model (TypeSafe Jev by default): an answer below `minConfidence` or a timeout steers. */
export const jevPrioritizer = ({
  model = "typesafe-ai/jev",
  timeoutMs = 1000,
  minConfidence = 0.6,
  criteria,
  queue = false,
}: Prioritize.JevOptions = {}): RunManager.Prioritize => {
  checkTimeout(timeoutMs);
  if (!(minConfidence >= 0 && minConfidence <= 1))
    throw new Error("prioritize: minConfidence must be in 0..1");
  const options = Object.fromEntries(
    modesOf(queue).map((mode) => [mode, criteria?.[mode] ?? CRITERIA[mode]]),
  );
  return async (req) => {
    const signal = deadline(req.signal, timeoutMs);
    try {
      const result = await experimental_decide({
        model,
        state: stateOf(req),
        questions: {
          mode: {
            type: "choice",
            instructions: INSTRUCTIONS,
            criteria: options,
          },
        },
        abortSignal: signal,
      });
      const answer = result.answers.mode;
      const typesafe = result.providerMetadata?.["typesafe"] as
        | { confidence?: Record<string, unknown> }
        | undefined;
      const reported = typesafe?.confidence?.["mode"];
      const confidence =
        typeof reported === "number"
          ? reported
          : answer.probabilities?.[answer.choice];
      if (confidence !== undefined && confidence < minConfidence)
        return "steer";
      return answer.choice as RunManager.Mode;
    } catch (error) {
      if (signal.aborted) return "steer";
      throw error;
    }
  };
};

export namespace Prioritize {
  export type LlmOptions = {
    model: LanguageModel;
    /** Default 1500. */
    timeoutMs?: number;
    /** Replaces the default system prompt. */
    prompt?: string;
    /** Lets the model choose "queue"; default false (steer or preempt only). */
    queue?: boolean;
  };

  export type JevOptions = {
    /** Default "typesafe-ai/jev". */
    model?: Experimental_DecisionModel;
    /** Default 1000. */
    timeoutMs?: number;
    /** An answer below it steers; default 0.6. */
    minConfidence?: number;
    /** Replaces the default description of each mode. */
    criteria?: Partial<Record<RunManager.Mode, string>>;
    /** Lets the model choose "queue"; default false (steer or preempt only). */
    queue?: boolean;
  };
}
