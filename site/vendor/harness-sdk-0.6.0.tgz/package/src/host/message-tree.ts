import { StatewireReject } from "statewire/host";

export namespace MessageTree {
  export type Node = {
    readonly parentId: string | null;
    readonly seq: number;
    readonly parts?: readonly unknown[];
  };
  export type Thread = {
    readonly messages: Readonly<Record<string, Node>>;
    readonly head: string | null;
  };
  export type Tree = Readonly<Record<string, Thread>>;
}

/**
 * Ids from `id` up to its root. A dangling parent or a parent cycle (a
 * transport that reused a message id) is a broken link: the walk stops with
 * `StatewireReject("unknown-message")` instead of running forever, so one bad
 * thread fails its own request without taking the host down.
 */
export function* ancestors(
  messages: Readonly<Record<string, { readonly parentId: string | null }>>,
  id: string | null,
): Generator<string> {
  const seen = new Set<string>();
  for (let cursor = id; cursor !== null;) {
    if (seen.has(cursor))
      throw broken(`message tree cycle at ${JSON.stringify(cursor)}`);
    seen.add(cursor);
    const node = Object.hasOwn(messages, cursor) ? messages[cursor] : undefined;
    if (!node) throw broken(`unknown message ${JSON.stringify(cursor)}`);
    yield cursor;
    cursor = node.parentId;
  }
}

const broken = (message: string) =>
  new StatewireReject(message, {
    code: "unknown-message",
    payload: { reason: "unknown-id" },
  });

/** Ids from the root down to `id`. */
export const chain = (thread: MessageTree.Thread, id: string): string[] =>
  [...ancestors(thread.messages, id)].reverse();

/** Children by parent id (`null` for roots), each list in creation order. */
export const childrenOf = (
  thread: MessageTree.Thread,
): Map<string | null, string[]> => {
  const byParent = new Map<string | null, string[]>();
  const ids = Object.keys(thread.messages).sort(
    (a, b) => thread.messages[a]!.seq - thread.messages[b]!.seq,
  );
  for (const id of ids) {
    const parent = thread.messages[id]!.parentId;
    const list = byParent.get(parent);
    if (list) list.push(id);
    else byParent.set(parent, [id]);
  }
  return byParent;
};

/** Follow the head chain below `id` when it is on it, else the newest child at each fork. */
export const leafOf = (
  thread: MessageTree.Thread,
  id: string,
  children = childrenOf(thread),
): string => {
  const onHead = new Set(
    thread.head === null ? [] : chain(thread, thread.head),
  );
  const seen = new Set<string>();
  let cursor = id;
  for (;;) {
    if (seen.has(cursor))
      throw broken(`message tree cycle at ${JSON.stringify(cursor)}`);
    seen.add(cursor);
    const kids = children.get(cursor);
    if (!kids?.length) return cursor;
    cursor = kids.find((c) => onHead.has(c)) ?? kids[kids.length - 1]!;
  }
};

/** Subagent namespaces named by a message's tool parts: harness parts carry `metadata.ns`, AI SDK parts `toolMetadata.ns`. */
export const spawnedNs = (node: MessageTree.Node): string[] => {
  const out: string[] = [];
  for (const part of node.parts ?? []) {
    const p = part as {
      type?: unknown;
      metadata?: { ns?: unknown };
      toolMetadata?: { ns?: unknown };
    };
    const ns =
      p.type === "tool"
        ? p.metadata?.ns
        : p.type === "dynamic-tool" ||
            (typeof p.type === "string" && p.type.startsWith("tool-"))
          ? p.toolMetadata?.ns
          : undefined;
    if (typeof ns === "string" && ns) out.push(ns);
  }
  return out;
};
