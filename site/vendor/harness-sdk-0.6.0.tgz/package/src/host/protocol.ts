import type { StatewireProtocol } from "statewire";
import { HARNESS_PROTOCOL } from "../protocol";

const SEND_VERSION = "2026-11-04";

const sendAs =
  (behavior: "queue" | "steer") =>
  ({ params }: StatewireProtocol.Command): StatewireProtocol.Command => {
    const [first, ...rest] = params;
    return {
      method: "run/send",
      params:
        typeof first === "object" && first !== null && !Array.isArray(first)
          ? [{ ...first, behavior }, ...rest]
          : params,
    };
  };

const toQueue = sendAs("queue");
const toSteer = sendAs("steer");

/** The harness protocol as a host registers it: main plus its resolved-interest subprotocol, and the adapter serving clients before `run/send`. */
export const HARNESS_HOST_PROTOCOL = {
  ...HARNESS_PROTOCOL,
  subprotocols: [{ name: "interest", record: "ephemeral" }],
  adapters: [
    {
      older: HARNESS_PROTOCOL.minVersion,
      newer: SEND_VERSION,
      commandUp: (command: StatewireProtocol.Command) =>
        command.method === "run/enqueue"
          ? toQueue(command)
          : command.method === "run/steer"
            ? toSteer(command)
            : command,
    },
  ],
} as const satisfies StatewireProtocol.Definition;
