import { StatewireReject } from "statewire/host";
import type { StatewireHost } from "statewire/host";
import type { Harness } from "../harness";
import type { RunManager } from "../runs";
import { isReservedId } from "./message-ids";
import {
  behaviorOf,
  createLine,
  decide,
  enterInOrder,
  plan,
} from "../runs/prioritize";
import type { DecisionLine } from "../runs/prioritize";
import { ancestors } from "./message-tree";

export const reject = (reason: RunCommands.RejectReason, message: string) =>
  new StatewireReject(message, { payload: { reason } });

export const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

export const checkUserMessage = (value: unknown): Harness.UserMessage => {
  if (!isRecord(value))
    throw reject("invalid-message", "message must be an object");
  const { id, role, parts, metadata } = value;
  if (typeof id !== "string" || !id)
    throw reject("invalid-message", "message.id must be a string");
  if (isReservedId(id))
    throw reject("invalid-message", `message.id "${id}" is reserved`);
  if (role !== "user")
    throw reject("invalid-message", 'message.role must be "user"');
  if (!Array.isArray(parts))
    throw reject("invalid-message", "message.parts must be an array");
  for (const part of parts) {
    if (!isRecord(part))
      throw reject("invalid-message", "part must be an object");
    if (part.type === "text") {
      if (typeof part.text !== "string")
        throw reject("invalid-message", "text part needs text");
    } else if (part.type === "file") {
      if (typeof part.mediaType !== "string" || typeof part.url !== "string")
        throw reject("invalid-message", "file part needs mediaType and url");
    } else
      throw reject(
        "invalid-message",
        `unsupported part type ${JSON.stringify(part.type)}`,
      );
  }
  if (metadata !== undefined && !isRecord(metadata))
    throw reject("invalid-message", "message.metadata must be an object");
  if (Object.hasOwn(value, "parentId"))
    throw reject(
      "invalid-message",
      "message.parentId is not a send field: runAnchorMessageId names the parent",
    );
  return {
    id,
    role,
    parts: parts as Harness.SendPart[],
    ...(metadata !== undefined && {
      metadata: metadata as Record<string, unknown>,
    }),
  };
};

/** Rejects a command carrying `requestOptions`, or a legacy `message.metadata.headers` / `.body`, on a host that doesn't accept them. */
const checkAccepted = (
  machine: RunCommands.Machine,
  params: Record<string, unknown>,
) => {
  if (machine.acceptsRequestOptions) return;
  const { message } = params;
  const metadata =
    isRecord(message) && isRecord(message.metadata) ? message.metadata : {};
  if (
    Object.hasOwn(params, "requestOptions") ||
    metadata.headers !== undefined ||
    metadata.body !== undefined
  )
    throw reject(
      "capability-missing",
      "requestOptions is accepted only by the AI SDK transport",
    );
};

const checkRequestOptions = (
  value: unknown,
): Harness.SendOptions | undefined => {
  if (value === undefined) return undefined;
  if (!isRecord(value))
    throw reject("invalid-message", "requestOptions must be an object");
  const { headers, body } = value;
  if (
    headers !== undefined &&
    !(
      isRecord(headers) &&
      Object.values(headers).every((v) => typeof v === "string")
    )
  )
    throw reject(
      "invalid-message",
      "requestOptions.headers must be an object of strings",
    );
  if (body !== undefined && !isRecord(body))
    throw reject("invalid-message", "requestOptions.body must be an object");
  const options = {
    ...(headers !== undefined && {
      headers: headers as Record<string, string>,
    }),
    ...(body !== undefined && { body }),
  };
  return Object.keys(options).length > 0 ? options : undefined;
};

const splitLegacy = (message: Harness.UserMessage) => {
  const { metadata, ...rest } = message;
  const { headers, body, ...kept } = metadata ?? {};
  if (headers === undefined && body === undefined)
    return { message, legacy: undefined };
  return {
    message: {
      ...rest,
      ...(Object.keys(kept).length > 0 && { metadata: kept }),
    },
    legacy: {
      ...(headers !== undefined && { headers }),
      ...(body !== undefined && { body }),
    },
  };
};

/** A send's message and its host-only `requestOptions`; the legacy `message.metadata.headers` / `.body` move into them and never stay on the message. */
const checkSend = (
  params: Record<string, unknown>,
): { message: Harness.UserMessage; requestOptions?: Harness.SendOptions } => {
  const { message, legacy } = splitLegacy(checkUserMessage(params.message));
  const requestOptions = checkRequestOptions(
    Object.hasOwn(params, "requestOptions") ? params.requestOptions : legacy,
  );
  return {
    message,
    ...(requestOptions !== undefined && { requestOptions }),
  };
};

/** A restored queue with each pre-`requestOptions` item's `message.metadata.headers` / `.body` moved into its `requestOptions` (`keep`) or dropped. */
export const restoredQueue = (
  queue: readonly RunCommands.QueueItem[],
  keep: boolean,
): RunCommands.QueueItem[] =>
  queue.map((item) => {
    const { message, legacy } = splitLegacy(item.message);
    if (legacy === undefined) return item;
    const { requestOptions, ...rest } = item;
    const kept = requestOptions ?? (legacy as Harness.SendOptions);
    return { ...rest, message, ...(keep && { requestOptions: kept }) };
  });

export const checkRunId = (value: unknown): string => {
  if (typeof value !== "string" || !value)
    throw reject("invalid-message", "runId must be a string");
  return value;
};

export const checkAnchor = (value: unknown): string | null => {
  if (value !== null && typeof value !== "string")
    throw reject("invalid-message", "runAnchorMessageId must be an id or null");
  return value;
};

export const checkPlacement = (
  params: Record<string, unknown>,
): RunCommands.Placement => {
  const placement: RunCommands.Placement = {};
  for (const field of ["insertAfter", "insertBefore"] as const) {
    const value = params[field];
    if (value === undefined) continue;
    if (typeof value !== "string")
      throw reject("invalid-message", `${field} must be a message id`);
    placement[field] = value;
  }
  return placement;
};

const LEAF_SEND_VERSION = "2026-11-02";

// walk the whole chain so a cycle rejects even when `id` sits inside it
const onHeadChain = (tree: RunCommands.Tree, id: string) =>
  [...ancestors(tree.messages, tree.headId)].includes(id);

/** The parent of a send under the harness-sdk `version` its attach negotiated: the run anchor, else the head; from `2026-11-02` a stale anchor yields the head. */
export const parentFor = (
  tree: RunCommands.Tree,
  anchor: string | null | undefined,
  version: string,
): string | null => {
  const parentId = anchor !== undefined ? anchor : tree.headId;
  if (parentId === null) {
    if (Object.keys(tree.messages).length > 0)
      throw reject("wrong-anchor", "a null anchor asserts an empty thread");
    return null;
  }
  if (!Object.hasOwn(tree.messages, parentId))
    throw reject("unknown-id", `anchor "${parentId}" names nothing`);
  return version >= LEAF_SEND_VERSION && onHeadChain(tree, parentId)
    ? tree.headId
    : parentId;
};

/** The `sourceId` node of an edit or reload, checked for role and anchor. */
export const sourceOf = <TNode extends RunCommands.Node>(
  tree: RunCommands.Tree<TNode>,
  params: Record<string, unknown>,
  role: "user" | "assistant",
): TNode => {
  const { sourceId } = params;
  if (typeof sourceId !== "string")
    throw reject("invalid-message", "sourceId must be a string");
  if (!Object.hasOwn(tree.messages, sourceId))
    throw reject("unknown-id", `source "${sourceId}" names nothing`);
  const node = tree.messages[sourceId]!;
  if (node.message.role !== role)
    throw reject(
      "invalid-message",
      `source "${sourceId}" is not a ${role} message`,
    );
  if (checkAnchor(params.runAnchorMessageId) !== node.parentId)
    throw reject(
      "wrong-anchor",
      "runAnchorMessageId is not the source's parent",
    );
  return node;
};

const valuesOf = (context: Readonly<Record<string, unknown>>) => {
  const values = context.values;
  if (values === undefined) return {};
  if (!isRecord(values))
    throw new Error("harness: context values must be an object");
  return structuredClone(values);
};

const queuedIn = (machine: RunCommands.Machine, id: string) =>
  machine.queue().find((item) => item.message.id === id);

const requireRun = (machine: RunCommands.Machine, runId: string) => {
  if (machine.live() && runId !== machine.runId())
    throw reject("unknown-run", `run "${runId}" is not the live run`);
};

/** RunManager's default queue bound, applied per participant to in-process transports. */
export const MAX_QUEUED = 50;
/** Most queued messages across participants: a backstop against client-id churn. */
export const MAX_QUEUED_TOTAL = 200;

/** The participant a queue share is keyed by: the caller's client id (in-process callers share one key). */
export const participantOf = (caller: StatewireHost.Caller): string => {
  try {
    return `client:${caller.clientId}`;
  } catch {
    return "in-process";
  }
};

/** Who queued each message still in the queue. */
type Owners = Map<string, string>;

type Ledger = { line: DecisionLine; owners: Owners };
declare const ledgerBrand: unique symbol;

/**
 * The state `runCommandHandlers` keeps between calls: the decision line that orders
 * sends and who queued each message. Create it once per transport, not per render,
 * or every render resets the order and each client's queue share.
 */
export const createRunLedger = (): RunCommands.Ledger =>
  ({
    line: createLine(),
    owners: new Map(),
  }) satisfies Ledger as unknown as RunCommands.Ledger;

const checkRoom = (
  machine: RunCommands.Machine,
  owners: Owners,
  participant: string,
  steer: boolean,
) => {
  if (steer || !machine.live()) return;
  const queue = machine.queue();
  const total = machine.maxQueuedTotal ?? MAX_QUEUED_TOTAL;
  if (queue.length >= total)
    throw reject("queue-full", `queue is full (${total} messages)`);
  const queued = new Set(queue.map((item) => item.message.id));
  for (const id of owners.keys()) if (!queued.has(id)) owners.delete(id);
  let mine = 0;
  for (const owner of owners.values()) if (owner === participant) mine++;
  const limit = machine.maxQueued ?? MAX_QUEUED;
  if (mine >= limit)
    throw reject(
      "queue-full",
      `queue is full (${limit} messages from this client)`,
    );
};

const send = async (
  machine: RunCommands.Machine,
  owners: Owners,
  participant: string,
  runId: string,
  { message, requestOptions }: ReturnType<typeof checkSend>,
  parentId: string | null,
  steer: boolean,
  placement?: RunCommands.Placement,
  values: Record<string, unknown> = {},
) => {
  checkRoom(machine, owners, participant, steer);
  if (
    Object.hasOwn(machine.tree().messages, message.id) ||
    queuedIn(machine, message.id)
  )
    throw reject("duplicate-id", `message "${message.id}" already exists`);
  machine.validateSend?.({ ...message, parentId, steer });
  // Messages only queue behind a live run; a stale entry is pruned on the next check.
  if (!steer && machine.live()) owners.set(message.id, participant);
  await machine.dispatch({
    kind: "send",
    message,
    parentId,
    steer,
    runId,
    values,
    ...(placement !== undefined && { placement }),
    ...(requestOptions !== undefined && { requestOptions }),
  });
};

type UIPart = {
  type?: unknown;
  text?: unknown;
  url?: unknown;
  mediaType?: unknown;
  filename?: unknown;
};

const sendPart = (part: UIPart): Harness.SendPart[] =>
  part.type === "text" && typeof part.text === "string"
    ? [{ type: "text", text: part.text }]
    : part.type === "file" &&
        typeof part.url === "string" &&
        typeof part.mediaType === "string"
      ? [
          {
            type: "file",
            url: part.url,
            mediaType: part.mediaType,
            ...(typeof part.filename === "string" && {
              filename: part.filename,
            }),
          },
        ]
      : [];

/** The user message the live turn answers: the nearest one above the head. */
const runMessages = (tree: RunCommands.Tree): Harness.UserMessage[] => {
  for (const id of ancestors(tree.messages, tree.headId)) {
    const node = tree.messages[id]! as RunCommands.Node & {
      metadata?: Record<string, unknown>;
    };
    if (node.message.role === "user") {
      const parts = (node.message as { parts?: readonly UIPart[] }).parts ?? [];
      return [
        {
          id,
          role: "user",
          parts: parts.flatMap(sendPart),
          ...(node.metadata !== undefined && { metadata: node.metadata }),
        },
      ];
    }
  }
  return [];
};

const consults = (
  machine: RunCommands.Machine,
  behavior: RunManager.Behavior,
): boolean =>
  behavior === "auto" && machine.live() && machine.prioritize !== undefined;

const modeOf = (
  machine: RunCommands.Machine,
  behavior: RunManager.Behavior,
  message: Harness.UserMessage | undefined,
): RunManager.Mode | Promise<RunManager.Mode> => {
  if (behavior !== "auto") return behavior;
  if (!machine.live()) return "queue";
  const { prioritize } = machine;
  if (prioritize === undefined || message === undefined) return "steer";
  const controller = new AbortController();
  const runId = machine.runId()!;
  const unsubscribe = machine.subscribe((): void => {
    if (!machine.live() || machine.runId() !== runId) controller.abort();
  });
  return decide(
    prioritize,
    {
      message,
      run: {
        runId,
        status: machine.running() ? "running" : "input-required",
        messages: runMessages(machine.tree()),
        steerQueue: [],
      },
      queue: machine
        .queue()
        .map((item) => item.message)
        .filter((item) => item.id !== message.id),
    },
    controller.signal,
  ).finally(unsubscribe);
};

const admit = async (
  machine: RunCommands.Machine,
  owners: Owners,
  line: DecisionLine,
  params: unknown,
  ctx: StatewireHost.Ctx,
) => {
  const values = valuesOf(ctx.context);
  if (!isRecord(params))
    throw reject("invalid-message", "params must be an object");
  checkAccepted(machine, params);
  const runId = checkRunId(params.runId);
  requireRun(machine, runId);
  const behavior = behaviorOf(params);
  if (behavior === null)
    throw reject(
      "invalid-message",
      'behavior must be one of "auto", "steer", "preempt", "queue"',
    );
  if (params.message === undefined) {
    const { messageId } = params;
    if (typeof messageId !== "string")
      throw reject("invalid-message", "messageId must be a string");
    if (Object.hasOwn(params, "requestOptions")) {
      checkRequestOptions(params.requestOptions);
      throw reject(
        "invalid-message",
        "requestOptions needs a message, not a messageId",
      );
    }
    const queued = queuedIn(machine, messageId);
    if (!queued)
      throw reject("unknown-id", `message "${messageId}" is not queued`);
    return enterInOrder(
      line,
      plan(consults(machine, behavior), () =>
        modeOf(machine, behavior, queued.message),
      ),
      async (mode) => {
        const entry = queuedIn(machine, messageId);
        if (!entry)
          throw reject("unknown-id", `message "${messageId}" is not queued`);
        if (mode === "queue") return;
        machine.setQueue([
          entry,
          ...machine.queue().filter((item) => item !== entry),
        ]);
        if (machine.suspended()) return;
        await machine.halt();
        machine.drain();
      },
    );
  }
  const checked = checkSend(params);
  const anchor =
    params.runAnchorMessageId === undefined
      ? undefined
      : checkAnchor(params.runAnchorMessageId);
  parentFor(machine.tree(), anchor, ctx.version);
  const placement = checkPlacement(params);
  return enterInOrder(
    line,
    plan(consults(machine, behavior), () =>
      modeOf(machine, behavior, checked.message),
    ),
    (mode) =>
      send(
        machine,
        owners,
        participantOf(ctx.caller),
        runId,
        checked,
        parentFor(machine.tree(), anchor, ctx.version),
        mode !== "queue",
        placement,
        values,
      ),
  );
};

/** The `run/*` command handlers of an in-process transport, validated on the wire and routed into `machine`. */
export const runCommandHandlers = (
  machine: RunCommands.Machine,
  ledger: RunCommands.Ledger,
) => {
  // Run control is open to every attached caller; attach authorization is the gate. A finer security-gate system is planned.
  const { line, owners } = ledger as unknown as Ledger;
  return {
    "run/send": function (
      this: StatewireHost.Ctx,
      params: RunCommands.SendParams,
    ) {
      return admit(machine, owners, line, params, this);
    },
    "run/edit": async function (
      this: StatewireHost.Ctx,
      params: {
        runId: string;
        message: Harness.UserMessage;
        sourceId: string;
        runAnchorMessageId: string | null;
        requestOptions?: Harness.SendOptions;
      },
    ) {
      if (!isRecord(params))
        throw reject("invalid-message", "params must be an object");
      checkAccepted(machine, params);
      const runId = checkRunId(params.runId);
      requireRun(machine, runId);
      const checked = checkSend(params);
      const node = sourceOf(machine.tree(), params, "user");
      await send(
        machine,
        owners,
        participantOf(this.caller),
        runId,
        checked,
        node.parentId,
        machine.live(),
        undefined,
        valuesOf(this.context),
      );
    },
    "run/reload": async function (
      this: StatewireHost.Ctx,
      params: {
        runId: string;
        sourceId: string;
        runAnchorMessageId: string | null;
        requestOptions?: Harness.SendOptions;
      },
    ) {
      if (!isRecord(params))
        throw reject("invalid-message", "params must be an object");
      checkAccepted(machine, params);
      const runId = checkRunId(params.runId);
      requireRun(machine, runId);
      const requestOptions = checkRequestOptions(params.requestOptions);
      const node = sourceOf(machine.tree(), params, "assistant");
      await machine.dispatch({
        kind: "reload",
        parentId: node.parentId,
        steer: true,
        runId,
        values: valuesOf(this.context),
        ...(requestOptions !== undefined && { requestOptions }),
      });
    },
    "run/stop": async ({
      runId,
      reason,
    }: {
      runId: string;
      reason?: string;
    }) => {
      if (reason !== undefined && typeof reason !== "string")
        throw reject("invalid-message", "reason must be a string");
      if (!machine.running() || machine.suspended()) return;
      if (runId !== machine.runId()) return;
      if (reason !== undefined) machine.setStopReason?.(reason);
      let failure: { error: unknown } | undefined;
      try {
        await machine.cancel?.();
      } catch (error) {
        failure = { error };
      }
      await machine.halt();
      machine.drain();
      if (failure) {
        const { error } = failure;
        machine.fail(error instanceof Error ? error.message : String(error));
      }
    },
    "run/input": function (
      this: StatewireHost.Ctx,
      params: {
        runId?: string;
        requestId: string;
        response: unknown;
      },
    ) {
      if (!isRecord(params))
        throw reject("invalid-message", "params must be an object");
      const { runId, requestId, response } = params;
      if (typeof requestId !== "string")
        throw reject("invalid-message", "requestId must be a string");
      if (runId !== undefined) requireRun(machine, checkRunId(runId));
      if (!machine.live())
        throw reject("wrong-state", "no run is awaiting input");
      if (
        !isRecord(response) ||
        (response.decision !== "approve" && response.decision !== "reject")
      )
        throw reject(
          "invalid-message",
          'response.decision must be "approve" or "reject"',
        );
      if (!machine.awaitsInput(requestId))
        throw reject(
          "unknown-id",
          `input request "${requestId}" is not awaiting an answer`,
        );
      machine.dispatch({
        kind: "input",
        requestId,
        decision: response.decision,
        values: valuesOf(this.context),
      });
    },
    "run/dequeue": ({
      runId,
      messageId,
    }: {
      runId: string;
      messageId: string;
    }) => {
      requireRun(machine, checkRunId(runId));
      const entry = queuedIn(machine, messageId);
      if (!entry)
        throw reject("unknown-id", `message "${messageId}" is not queued`);
      machine.setQueue(machine.queue().filter((item) => item !== entry));
    },
    "run/continue": (_params?: { runId?: string }) => {
      throw reject("capability-missing", "run/continue is not supported");
    },
  };
};

export namespace RunCommands {
  /** Opaque handler state from `createRunLedger`; keep one per transport across renders. */
  export type Ledger = { readonly [ledgerBrand]: true };

  export type RejectReason =
    | "invalid-message"
    | "unknown-id"
    | "unknown-run"
    | "duplicate-id"
    | "wrong-anchor"
    | "wrong-state"
    | "queue-full"
    | "capability-missing";

  export type Placement = { insertAfter?: string; insertBefore?: string };

  export type Node = {
    readonly parentId: string | null;
    readonly message: { readonly role: string };
  };

  export type Tree<TNode extends Node = Node> = {
    readonly messages: Readonly<Record<string, TNode>>;
    readonly headId: string | null;
  };

  /** A queued send as the host holds it; only `message` is published. */
  export type QueueItem = {
    message: Harness.UserMessage;
    values?: Record<string, unknown> | undefined;
    requestOptions?: Harness.SendOptions | undefined;
  };

  export type SendParams = Parameters<Harness.Commands["run/send"]>[0];

  /** A validated send: the wire user message with its resolved parent. */
  export type Send = Harness.UserMessage & {
    parentId: string | null;
    steer: boolean;
  };

  export type Command =
    | {
        kind: "send";
        message: Harness.UserMessage;
        parentId: string | null;
        steer: boolean;
        runId: string;
        placement?: Placement;
        values?: Record<string, unknown> | undefined;
        requestOptions?: Harness.SendOptions | undefined;
      }
    | {
        kind: "reload";
        parentId: string | null;
        steer: boolean;
        runId: string;
        values?: Record<string, unknown> | undefined;
        requestOptions?: Harness.SendOptions | undefined;
      }
    | {
        kind: "input";
        requestId: string;
        decision: "approve" | "reject";
        values?: Record<string, unknown> | undefined;
      };

  /** What the handlers drive: the live tree and queue plus the run host verbs. */
  export type Machine = {
    tree(): Tree;
    queue(): readonly QueueItem[];
    setQueue(queue: QueueItem[]): void;
    /** The live run's id; `undefined` while resting. */
    runId(): string | undefined;
    running(): boolean;
    suspended(): boolean;
    /** Running or suspended. */
    live(): boolean;
    dispatch(cmd: Command): void | Promise<void>;
    /** Whether the live run shows `requestId` as an open input request with no answer delivered yet; `run/input` refuses any other id. */
    awaitsInput(requestId: string): boolean;
    halt(): Promise<void>;
    drain(): void;
    /** Record a thread error. */
    fail(message: string): void;
    /** Record the reason `run/stop` gives the live run, ahead of its halt. */
    setStopReason?(reason: string): void;
    /** Cancel the live run outside the loop (e.g. server-side); `run/stop` halts afterwards regardless and a throw surfaces via `fail`. */
    cancel?(): Promise<void>;
    /** Most messages one participant (client id) holds in the queue while a run is live; defaults to `MAX_QUEUED`. */
    maxQueued?: number;
    /** Most messages the queue holds across participants while a run is live; defaults to `MAX_QUEUED_TOTAL`. */
    maxQueuedTotal?: number;
    /** Reject a send before any state changes. */
    validateSend?(send: Send): void;
    /** Accepts host-only `requestOptions` on `run/send`, `run/edit` and `run/reload`; only the AI SDK transport does, every other host rejects them. */
    acceptsRequestOptions?: boolean;
    /** Places an "auto" send while a run is live; steer and preempt both preempt here. */
    prioritize?: RunManager.Prioritize;
    /** Notifies on every state commit. */
    subscribe(listener: () => void): () => void;
  };
}
