/**
 * Wraps `fetch` so a non-ok backend response keeps its status but not its
 * body: the body is logged on this host, and callers read
 * `upstream returned HTTP <status>`. Transport errors land in thread state
 * that every subscriber reads, so backend error text must not reach it.
 */
export const redactedFetch = (
  inner: typeof globalThis.fetch = (input, init) =>
    globalThis.fetch(input, init),
  label = "harness",
): typeof globalThis.fetch =>
  (async (input: RequestInfo | URL, init?: RequestInit) => {
    const response = await inner(input, init);
    if (response.ok || response.body === null) return response;
    const body = await response.text().catch(() => "");
    console.error(
      `${label}: upstream returned HTTP ${response.status}`,
      body.slice(0, 4096),
    );
    return new Response(`upstream returned HTTP ${response.status}`, {
      status: response.status,
      statusText: response.statusText,
      headers: { "content-type": "text/plain" },
    });
  }) as typeof globalThis.fetch;
