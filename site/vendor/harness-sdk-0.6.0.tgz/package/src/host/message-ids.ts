/**
 * The one id no store can hold: assigning `__proto__` on an ordinary object
 * replaces its prototype instead of storing a value. Every other id, including
 * `Object.prototype` names like `toString` or `constructor`, is a plain key:
 * id-keyed records have no prototype and every lookup checks own properties.
 */
export const isReservedId = (id: string) => id === "__proto__";

/** An empty id-keyed record with no prototype, so no id can reach `Object.prototype`. */
export const idRecord = <T>(): Record<string, T> =>
  Object.create(null) as Record<string, T>;

/** `record[id]` when `record` holds `id` itself; never an inherited member. */
export const own = <T>(
  record: Readonly<Record<string, T>>,
  id: string,
): T | undefined => (Object.hasOwn(record, id) ? record[id] : undefined);

type TreeNode = { parentId: string | null; seq: number };

/**
 * A message tree rebuilt on a null-prototype record: reserved ids are dropped,
 * their children reattach to the dropped node's parent (or become roots), and a
 * head that names a dropped or missing node falls back to the newest node.
 * Loads trees that a reserved id corrupted before ids were checked.
 */
export const repairTree = <TNode extends TreeNode>(
  messages: Readonly<Record<string, TNode>>,
  headId: string | null,
): { messages: Record<string, TNode>; headId: string | null } => {
  const dropped = new Map<string, string | null>();
  const kept: [string, TNode][] = [];
  for (const [id, node] of Object.entries(messages)) {
    if (isReservedId(id)) dropped.set(id, node.parentId);
    else kept.push([id, node]);
  }
  const ids = new Set(kept.map(([id]) => id));
  const liveParent = (parentId: string | null): string | null => {
    const seen = new Set<string>();
    let cursor = parentId;
    while (cursor !== null && !ids.has(cursor)) {
      if (seen.has(cursor) || !dropped.has(cursor)) return null;
      seen.add(cursor);
      cursor = dropped.get(cursor)!;
    }
    return cursor;
  };
  const out = idRecord<TNode>();
  for (const [id, node] of kept) {
    const parentId = liveParent(node.parentId);
    out[id] = parentId === node.parentId ? node : { ...node, parentId };
  }
  const newest = () =>
    kept.reduce<[string, TNode] | undefined>(
      (best, entry) =>
        best === undefined || entry[1].seq > best[1].seq ? entry : best,
      undefined,
    )?.[0] ?? null;
  const head = headId === null || ids.has(headId) ? headId : newest();
  return { messages: out, headId: head };
};
