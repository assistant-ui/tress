import {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { useResource, useTapRoot } from "@assistant-ui/tap";
import { StatewireSendError, useStatewire } from "statewire";
import { harnessCanOvertake } from "./can-overtake";
import type { StatewireDocuments } from "statewire";
import {
  DEFAULT_WINDOW,
  HARNESS_PROTOCOL,
  INTEREST_PROTOCOL,
  MAIN_NS,
  headRequest,
} from "./protocol";
import { WebRtcMedia } from "./voice";
import type { Harness } from "./harness";

const CAN_OVERTAKE = { [HARNESS_PROTOCOL.name]: harnessCanOvertake };

type State = Harness.ReadonlyDeep<Harness.State>;
type Request = Harness.Interest.Request;
type Resolution = Harness.Interest.Resolution;
type Documents = ReadonlyMap<number, StatewireDocuments.Document>;

const MAX_WINDOW = 200;
const EMPTY_STATE: State = { threads: {}, status: "ready", runs: [] };
const NO_DOCUMENTS: Documents = new Map();
const NO_MESSAGES: readonly Harness.Message[] = [];
const NO_FOLLOWS: Harness.Helpers["follows"] = {};
const NO_MORE: Harness.Interest.More = { before: false, after: false };
const noop = () => () => {};

const newId = () => crypto.randomUUID();

const sameIds = (a: readonly string[], b: readonly string[]) =>
  a.length === b.length && a.every((id, i) => id === b[i]);

const base64 = (bytes: Uint8Array) => {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000)
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
};

const readFiles = (files: FileList): Promise<Harness.FilePart[]> =>
  Promise.all(
    Array.from(files, async (file) => ({
      type: "file" as const,
      mediaType: file.type,
      url: `data:${file.type};base64,${base64(new Uint8Array(await file.arrayBuffer()))}`,
      ...(file.name !== "" && { filename: file.name }),
    })),
  );

/** Runs `send` with a `FileList` read into file parts; other inputs run synchronously so validation throws. */
const withFiles = (
  input: Harness.SendMessageInput,
  send: (input: Harness.SendMessage) => Promise<void>,
) => {
  const message = typeof input === "string" ? { text: input } : input;
  return message.files === undefined || Array.isArray(message.files)
    ? send(message)
    : readFiles(message.files).then((files) => send({ ...message, files }));
};

const requestOptionsOf = (options: Harness.SendOptions | undefined) => {
  const requestOptions = {
    ...(options?.headers !== undefined && { headers: options.headers }),
    ...(options?.body !== undefined && { body: options.body }),
  };
  return Object.keys(requestOptions).length > 0 ? { requestOptions } : {};
};

const toUserMessage = ({
  text,
  files,
  metadata,
}: Harness.SendMessage): Harness.UserMessage => {
  if (files !== undefined && !Array.isArray(files))
    throw new Error("harness: FileList must be read before the send");
  const parts: Harness.SendPart[] = [
    ...(files ?? []),
    ...(text !== undefined ? [{ type: "text" as const, text }] : []),
  ];
  if (parts.length === 0)
    throw new Error("harness: a message needs text or files");
  return {
    id: newId(),
    role: "user",
    parts,
    ...(metadata !== undefined && { metadata: { metadata } }),
  };
};

type Placing = {
  readonly message: Harness.UserMessage;
  readonly lane: "queue" | "steerQueue";
};

const NO_WINDOWS: readonly Resolution[] = [];
const EMPTY_CONTEXT = {};

const interestDocuments = (documents: Documents) => {
  let threadId: string | undefined;
  let windows = NO_WINDOWS;
  for (const document of documents.values()) {
    if (!document.main) continue;
    if (document.protocol === HARNESS_PROTOCOL.name)
      threadId = document.key?.[0];
    if (document.protocol === INTEREST_PROTOCOL)
      windows = (document.value as Harness.Interest.Document).windows;
  }
  return { threadId, windows };
};

/** Pages are anchored at the previous window's oldest message: drop the shared anchor when joining. */
const joinWindows = (windows: readonly Resolution[]) => {
  const main = windows[0];
  if (main === undefined) return { chain: [], more: NO_MORE };
  let chain = main.chain;
  let more = main.more;
  for (const page of windows.slice(1)) {
    if (page.at !== chain[0]?.id) break;
    chain = [...page.chain.slice(0, -1), ...chain];
    more = { before: page.more.before, after: main.more.after };
  }
  return { chain, more };
};

const useMaterializer = (
  documents: StatewireDocuments.Source | undefined,
  threadId: string | undefined,
) => {
  const [caches] = useState(() => ({
    messages: new WeakMap<object, Harness.Message>(),
    chains: new Map<string, readonly Harness.Message[]>(),
  }));
  return (ns: string, chain: readonly Harness.Interest.Entry[]) => {
    if (chain.length === 0) return NO_MESSAGES;
    if (documents === undefined || threadId === undefined)
      throw new Error("harness: message window without documents");
    const messages = chain.map((entry) => {
      const document = documents.get(HARNESS_PROTOCOL.name, [
        threadId,
        ns,
        entry.id,
      ]);
      if (document === undefined)
        throw new Error(
          `harness: message "${entry.id}" of "${ns}" is not mounted`,
        );
      const cached = caches.messages.get(document as object);
      if (cached !== undefined && sameIds(cached.siblings, entry.siblings))
        return cached;
      const message = {
        ...(document as Harness.Message.Document),
        siblings: entry.siblings,
      } as Harness.Message;
      caches.messages.set(document as object, message);
      return message;
    });
    const previous = caches.chains.get(ns);
    if (
      previous !== undefined &&
      previous.length === messages.length &&
      previous.every((m, i) => m === messages[i])
    )
      return previous;
    caches.chains.set(ns, messages);
    return messages;
  };
};

const withPending = (
  materialized: readonly Harness.Message[],
  pending: readonly Harness.Message[],
) => {
  let chain = materialized;
  for (const message of pending) {
    if (chain.some((m) => m.id === message.id)) continue;
    const parent = chain.findIndex((m) => m.id === message.parentId);
    chain = [
      ...(parent === -1 && message.parentId === null
        ? []
        : chain.slice(0, parent === -1 ? undefined : parent + 1)),
      message,
    ];
  }
  return chain;
};

const sessionListed = (voice: State["voice"]) =>
  voice != null && voice.status !== "closed";

const useHarnessValue = ({
  transport,
  isNew,
  window = DEFAULT_WINDOW,
  voice,
  context: providedContext = EMPTY_CONTEXT,
}: Harness.Options): Harness.Helpers => {
  if (!Number.isInteger(window) || window < 1 || window > MAX_WINDOW)
    throw new Error(`harness: window must be an integer in 1..${MAX_WINDOW}`);
  const [commandError, setCommandError] = useState<Harness.Error | undefined>(
    undefined,
  );
  const [interests, setInterests] = useState<readonly Request[]>(() => [
    headRequest(window),
  ]);
  const [contextOverride, setContextOverride] = useState<{
    provided: Record<string, unknown>;
    value: Record<string, unknown>;
  }>();
  const context =
    contextOverride?.provided === providedContext
      ? contextOverride.value
      : providedContext;
  const interestsRef = useRef(interests);
  interestsRef.current = interests;
  const contextRef = useRef(context);
  contextRef.current = context;
  const [pending, setPending] = useState<readonly Harness.Message[]>([]);
  const [placing, setPlacing] = useState<readonly Placing[]>([]);
  const leaseContext = useMemo(
    () => ({
      [HARNESS_PROTOCOL.name]: { interest: interests, values: context },
    }),
    [interests, context],
  );
  const wire = useStatewire<State | undefined, Harness.Commands>({
    protocol: HARNESS_PROTOCOL.name,
    applicationProtocols: [HARNESS_PROTOCOL],
    transport,
    context: leaseContext,
    canOvertake: CAN_OVERTAKE,
    ...(isNew !== undefined && { isNew }),
    onCommandChange: (update) => {
      if (update.status !== "settled") return;
      setCommandError(
        update.failure
          ? { message: new StatewireSendError(update.failure).message }
          : undefined,
      );
    },
  });
  const { connection, documents, commands, getState: getWireState } = wire;
  const getState = () => getWireState() ?? EMPTY_STATE;
  const isLoading = wire.state === undefined && isNew !== true;
  const state = wire.state ?? EMPTY_STATE;

  const updateInterests = (
    update:
      | readonly Request[]
      | ((current: readonly Request[]) => readonly Request[]),
  ) => {
    const next =
      typeof update === "function" ? update(interestsRef.current) : update;
    interestsRef.current = next;
    wire.setContext(HARNESS_PROTOCOL.name, {
      interest: next,
      values: contextRef.current,
    });
    setInterests(next);
  };
  const updateContext = (value: Record<string, unknown>) => {
    contextRef.current = value;
    wire.setContext(HARNESS_PROTOCOL.name, {
      interest: interestsRef.current,
      values: value,
    });
    setContextOverride({ provided: providedContext, value });
  };

  const mounted = useSyncExternalStore(
    documents?.subscribe ?? noop,
    () => documents?.list() ?? NO_DOCUMENTS,
    () => documents?.list() ?? NO_DOCUMENTS,
  );
  const { threadId, windows } = useMemo(
    () => interestDocuments(mounted),
    [mounted],
  );
  const materialize = useMaterializer(documents, threadId);
  const { materialized, more, follows } = useMemo(() => {
    const joined = joinWindows(windows);
    const main = windows[0];
    const follows: Record<string, readonly Harness.Message[]> = {};
    for (const [ns, window] of Object.entries(main?.follows ?? {}))
      follows[ns] = materialize(ns, window.chain);
    return {
      materialized: materialize(MAIN_NS, joined.chain),
      more: joined.more,
      follows: main?.follows === undefined ? NO_FOLLOWS : follows,
    };
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted]);
  const messages = useMemo(
    () => withPending(materialized, pending),
    [materialized, pending],
  );
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const materializedRef = useRef(materialized);
  materializedRef.current = materialized;
  const pendingRef = useRef(pending);
  pendingRef.current = pending;

  const overlay =
    connection.status === "connected" ||
    (connection.status === "standby" && connection.reason === "idle")
      ? undefined
      : connection.status === "retrying" &&
          connection.cause === "reconnect" &&
          connection.code === "evicted"
        ? ("evicted" as const)
        : ("disconnected" as const);
  const mainThread = state.threads[MAIN_NS];
  const threadStatus = mainThread?.status ?? "idle";
  const status: Harness.Status =
    overlay !== undefined && threadStatus !== "idle" ? overlay : threadStatus;
  const run = state.runs[0];

  const media = useResource(voice?.media ?? WebRtcMedia());
  const mediaLive = media.connection.status === "live";
  const hostListed = sessionListed(state.voice);
  useEffect(() => {
    // The host closing the session (or a lost transport) retires the media leg; voice/end is not owed.
    if (mediaLive && (!hostListed || overlay !== undefined)) media.close();
  }, [media, mediaLive, hostListed, overlay]);

  return useMemo<Harness.Helpers>(() => {
    const liveRunId = () => getState().runs[0]?.runId;
    const lane = (name: Placing["lane"]) => {
      const items = run?.[name] ?? [];
      const placed = new Set(
        [...(run?.queue ?? []), ...(run?.steerQueue ?? [])].map((m) => m.id),
      );
      const optimistic = placing.filter(
        (p) => p.lane === name && !placed.has(p.message.id),
      );
      return optimistic.length === 0
        ? items
        : [...items, ...optimistic.map((p) => p.message)];
    };
    const followHead = () => updateInterests([headRequest(window)]);
    const branchRequest = (at: string) => ({
      ns: MAIN_NS,
      at,
      before: window,
      after: MAX_WINDOW,
      follow: { before: window },
    });
    const settle = (result: Promise<unknown>) => {
      setCommandError(undefined);
      const settled = result.then(() => {});
      settled.catch(() => {});
      return settled;
    };
    const dispatch = (
      message: Harness.UserMessage,
      parentId: string | null,
      result: Promise<unknown>,
    ) => {
      const optimistic: Harness.Message = {
        id: message.id,
        role: "user",
        parts: message.parts,
        parentId,
        seq: (messagesRef.current.at(-1)?.seq ?? -1) + 1,
        siblings: [message.id],
      };
      setPending((current) => [...current, optimistic]);
      pendingRef.current = [...pendingRef.current, optimistic];
      const forget = () =>
        setPending((current) => current.filter((m) => m !== optimistic));
      // The view re-renders later; the next send must not anchor to a rejected one meanwhile.
      const rollBack = () => {
        pendingRef.current = pendingRef.current.filter((m) => m !== optimistic);
        messagesRef.current = withPending(
          materializedRef.current,
          pendingRef.current,
        );
        forget();
      };
      result.then(forget, rollBack);
      return settle(result);
    };
    const targetRun = () => {
      const runId = liveRunId();
      if (runId === undefined) throw new Error("harness: no run is live");
      return runId;
    };
    const find = (messageId: string) => {
      const message = messagesRef.current.find((m) => m.id === messageId);
      if (message === undefined)
        throw new Error(`harness: message "${messageId}" is not in view`);
      return message;
    };
    const send = (
      input: Harness.SendMessage,
      options: Harness.SendOptions | undefined,
    ) => {
      const message = toUserMessage(input);
      const requestOptions = requestOptionsOf(options);
      const { messageId, behavior = "auto" } = input;
      if (messageId !== undefined) {
        if (input.behavior !== undefined)
          throw new Error("harness: messageId and behavior are exclusive");
        const source = find(messageId);
        followHead();
        return dispatch(
          message,
          source.parentId,
          commands["run/edit"]({
            runId: liveRunId() ?? newId(),
            message,
            sourceId: messageId,
            runAnchorMessageId: source.parentId,
            ...requestOptions,
          }),
        );
      }
      const runId = liveRunId();
      const anchor = messagesRef.current.at(-1)?.id ?? null;
      if (
        runId === undefined &&
        anchor !== null &&
        interestsRef.current[0]!.at !== undefined
      )
        updateInterests([branchRequest(anchor)]);
      else followHead();
      if (runId === undefined)
        return dispatch(
          message,
          anchor,
          commands["run/send"]({
            runId: newId(),
            message,
            runAnchorMessageId: anchor,
            behavior,
            ...requestOptions,
          }),
        );
      const result = commands["run/send"]({
        runId,
        message,
        behavior,
        ...requestOptions,
      });
      const optimistic: Placing = {
        message,
        lane: behavior === "queue" ? "queue" : "steerQueue",
      };
      setPlacing((current) => [...current, optimistic]);
      const forget = () =>
        setPlacing((current) => current.filter((p) => p !== optimistic));
      result.then(forget, forget);
      return settle(result);
    };
    return {
      setContext: updateContext,
      transport: {
        status: connection.status,
        connection,
        error: connection.error
          ? { message: connection.error.message }
          : undefined,
      },
      status,
      isBusy: threadStatus !== "idle" || pending.length > 0,
      isLoading,
      error:
        mainThread?.error !== undefined
          ? { message: mainThread.error }
          : commandError,
      messages,
      more,
      follows,
      threads: state.threads,
      queue: lane("queue"),
      steerQueue: lane("steerQueue"),
      inputRequests: run?.inputRequests ?? [],
      rawState: state,
      sendMessage: (input, options) =>
        withFiles(input, (message) => send(message, options)),
      reload: (messageId, options) => {
        const source = find(messageId);
        followHead();
        return settle(
          commands["run/reload"]({
            runId: liveRunId() ?? newId(),
            sourceId: messageId,
            runAnchorMessageId: source.parentId,
            ...requestOptionsOf(options),
          }),
        );
      },
      switchToBranch: (messageId) =>
        updateInterests([branchRequest(messageId)]),
      loadMore: () =>
        updateInterests((current) => {
          const [main, ...pages] = current as [Request, ...Request[]];
          if (main.before < MAX_WINDOW)
            return [
              { ...main, before: Math.min(MAX_WINDOW, main.before + window) },
              ...pages,
            ];
          const oldest = messagesRef.current[0]?.id;
          if (oldest === undefined || current.at(-1)!.at === oldest)
            return current;
          return [
            ...current,
            { ns: MAIN_NS, at: oldest, before: MAX_WINDOW, after: 0 },
          ];
        }),
      respond: (requestId, response) =>
        settle(
          commands["run/input"]({
            ...(liveRunId() !== undefined && { runId: liveRunId()! }),
            requestId,
            response,
          }),
        ),
      stop: () => {
        const runId = liveRunId();
        return runId === undefined
          ? Promise.resolve()
          : settle(commands["run/stop"]({ runId }));
      },
      move: (messageId, behavior) =>
        settle(
          commands["run/send"]({ runId: targetRun(), messageId, behavior }),
        ),
      dequeue: (messageId) =>
        settle(commands["run/dequeue"]({ runId: targetRun(), messageId })),
      voice: {
        state: state.voice ?? null,
        connection: media.connection,
        start: () => {
          const opening = media.open((offer) =>
            commands["voice/start"]({ transport: "webrtc", offer }).then(
              (result) => result.answer,
            ),
          );
          // Interrupted or failed after the host answered: the session it opened is ours to end.
          const reconcile = (live: boolean) => {
            if (!live && sessionListed(getState().voice))
              void settle(commands["voice/end"]());
          };
          return settle(
            opening.then(reconcile, (error) => {
              reconcile(false);
              throw error;
            }),
          );
        },
        // An end while connecting is settled by `start`; only a live leg owes voice/end here.
        end: () =>
          media.close() === "live" && sessionListed(getState().voice)
            ? settle(commands["voice/end"]())
            : Promise.resolve(),
        setMicPaused: (paused) => {
          media.setMicEnabled(!paused);
          return settle(commands["voice/mic"]({ paused }));
        },
      },
    };
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, [
    connection,
    media,
    state,
    isLoading,
    status,
    threadStatus,
    run,
    mainThread,
    commandError,
    commands,
    pending,
    placing,
    messages,
    more,
    follows,
    window,
    context,
    providedContext,
  ]);
};

/**
 * React hook mirroring the AI SDK's `useChat`: `messages` is the viewed
 * window of the main thread and the component re-renders as tokens stream.
 */
export const useHarness = (options: Harness.Options): Harness.Helpers => {
  const HarnessRoot = () => useHarnessValue(options);
  const root = useTapRoot(HarnessRoot);
  return useSyncExternalStore(root.subscribe, root.getValue, root.getValue);
};
