/**
 * Workspace-internal helpers shared by the harness-sdk transport packages.
 * Not public API: no docs, no compatibility promise, may change in any release.
 */
export { idRecord, isReservedId, own, repairTree } from "./host/message-ids";
