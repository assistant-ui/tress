import type { RunManager } from "../runs";

const MODES: readonly string[] = ["steer", "preempt", "queue"];

const isMode = (value: unknown): value is RunManager.Mode =>
  typeof value === "string" && MODES.includes(value);

export const behaviorOf = (
  params: Record<string, unknown>,
): RunManager.Behavior | null => {
  if (!("behavior" in params)) return "auto";
  const { behavior } = params;
  return behavior === "auto" || isMode(behavior) ? behavior : null;
};

/** The prioritizer's mode; a rejection or an invalid mode steers, and so does an abort. */
export const decide = (
  prioritize: RunManager.Prioritize,
  request: Omit<RunManager.PrioritizeRequest, "signal">,
  signal: AbortSignal,
): Promise<RunManager.Mode> =>
  new Promise((resolve) => {
    let done = false;
    const finish = (mode: RunManager.Mode, warning?: string) => {
      if (done) return;
      done = true;
      signal.removeEventListener("abort", onAbort);
      if (warning !== undefined)
        console.warn(`harness-sdk: prioritize ${warning}; steering`);
      resolve(mode);
    };
    const onAbort = () => finish("steer");
    if (signal.aborted) return onAbort();
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve()
      .then(() => prioritize({ ...request, signal }))
      .then(
        (mode) =>
          isMode(mode)
            ? finish(mode)
            : finish("steer", `returned ${describe(mode)}`),
        (error: unknown) =>
          finish(
            "steer",
            `failed: ${error instanceof Error ? error.message : String(error)}`,
          ),
      );
  });

const describe = (value: unknown): string => {
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return typeof value;
  }
};

export type DecisionLine = {
  tail: Promise<void> | null;
  /** Admissions entered but not yet applied. */
  admitting: Set<Promise<void>>;
};

export const createLine = (): DecisionLine => ({
  tail: null,
  admitting: new Set(),
});

const noop = () => {};

/** `resolve` as the line takes it: deferred when it asks a prioritizer, else its mode now. */
export const plan = (
  consults: boolean,
  resolve: () => RunManager.Mode | Promise<RunManager.Mode>,
): RunManager.Mode | (() => RunManager.Mode | Promise<RunManager.Mode>) =>
  consults ? resolve : (resolve() as RunManager.Mode);

const track = <T>(line: DecisionLine, result: Promise<T>): Promise<T> => {
  const settled = result.then(noop, noop);
  line.admitting.add(settled);
  void settled.then(() => line.admitting.delete(settled));
  return result;
};

/** Enters sends in arrival order. A `decide` callback runs once every earlier send has entered and applied, so it reads the lanes they produced; an explicit mode with nothing pending enters synchronously. */
export const enterInOrder = <T>(
  line: DecisionLine,
  mode: RunManager.Mode | (() => RunManager.Mode | Promise<RunManager.Mode>),
  enter: (mode: RunManager.Mode) => Promise<T>,
): Promise<T> => {
  if (typeof mode === "string" && line.tail === null)
    return track(line, enter(mode));
  const settled = () => Promise.all([...line.admitting]);
  const ready =
    typeof mode === "string"
      ? line.tail!
      : line.tail === null
        ? settled()
        : line.tail.then(settled);
  const entered = ready
    .then(() => (typeof mode === "string" ? mode : mode()))
    .then((resolved) => ({ result: track(line, enter(resolved)) }));
  const tail = entered.then(noop, noop);
  line.tail = tail;
  void tail.then(() => {
    if (line.tail === tail) line.tail = null;
  });
  return entered.then(({ result }) => result);
};
