import type { StatewireClient } from "statewire";

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const MESSAGE_KEYS = ["messageId", "sourceId", "runAnchorMessageId"] as const;

// The runs, messages, threads and input requests a command creates or
// references, read off its params object.
const entities = (command: StatewireClient.OutboxEntry["command"]) => {
  const params = command.params[0];
  if (!isRecord(params)) return [];
  const found: string[] = [];
  if (typeof params["runId"] === "string") found.push(`run:${params["runId"]}`);
  if (typeof params["threadId"] === "string")
    found.push(`thread:${params["threadId"]}`);
  if (typeof params["requestId"] === "string")
    found.push(`request:${params["requestId"]}`);
  for (const key of MESSAGE_KEYS)
    if (typeof params[key] === "string") found.push(`message:${params[key]}`);
  const message = params["message"];
  if (isRecord(message) && typeof message["id"] === "string")
    found.push(`message:${message["id"]}`);
  return found;
};

/** The `harness-sdk` protocol's `canOvertake`: a command never moves ahead of one that creates or references the same run, message, thread or input request. */
export const harnessCanOvertake: StatewireClient.CanOvertake = (
  entry,
  ahead,
) => {
  // Voice commands act on the one voice session: they keep their order.
  if (
    entry.command.method.startsWith("voice/") &&
    ahead.command.method.startsWith("voice/")
  )
    return false;
  const blocking = new Set(entities(ahead.command));
  return !entities(entry.command).some((id) => blocking.has(id));
};
