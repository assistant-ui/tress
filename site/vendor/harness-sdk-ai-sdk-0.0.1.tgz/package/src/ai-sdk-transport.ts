import { useEffect, useRef, useState } from "react";
import { resource } from "@assistant-ui/tap";
import { DefaultChatTransport } from "ai";
import type { ChatInit, ChatTransport, UIMessage } from "ai";
import type { Harness } from "harness-sdk";
import { HARNESS_PROTOCOL, MAIN_NS } from "harness-sdk";
import { useProjection, useRunHost } from "harness-sdk/host";
import type { RunHost } from "harness-sdk/host";
import {
  CONTEXT_PROTOCOL,
  INTEREST_PROTOCOL,
  isToolLikePart,
  runCommandHandlers,
  toUIUserMessage,
  useThreadDocuments,
} from "harness-sdk/ui-transport";
import type { RunCommands, ThreadDocuments } from "harness-sdk/ui-transport";
import type { Statewire } from "statewire";
import {
  getStateHost,
  syncedDocument,
  useStatewireCommands,
  useStatewireState,
} from "statewire/host";
import { HarnessChat, chatTreeState } from "./chat-tree";
import type { ChatTree } from "./chat-tree";
import { useVoiceHost } from "./voice";
import type { VoiceHost } from "./voice";
import {
  delegationEntry,
  delegationId,
  delegationNs,
  delegationTask,
  deliverOverlay,
  overlaidView,
  settleDelegation,
  trailingAssistantText,
  upsertVoiceTurn,
  voiceSeed,
} from "./voice-thread";
import type { VoiceOverlay } from "./voice-thread";

const abortError = () => new DOMException("aborted", "AbortError");

type MessagePart = UIMessage["parts"][number];
type ApprovalRequestedPart = Extract<
  MessagePart,
  { state: "approval-requested"; approval: { id: string } }
>;

const isApprovalRequestedPart = (
  part: MessagePart,
): part is ApprovalRequestedPart =>
  isToolLikePart(part) && part.state === "approval-requested";

const pendingApprovals = (message: UIMessage | undefined) =>
  message?.role === "assistant"
    ? message.parts.filter(isApprovalRequestedPart)
    : [];

const denyPending = (message: UIMessage): UIMessage => ({
  ...message,
  parts: message.parts.map((part) =>
    isApprovalRequestedPart(part)
      ? {
          ...part,
          state: "approval-responded",
          approval: { ...part.approval, approved: false },
        }
      : part,
  ),
});

type Cmd = RunCommands.Command | { kind: "resume" };

const useAISDKTransport = (
  options: AISDKTransport.Options,
): AISDKTransport.Instance => {
  const { threadId } = options;
  if (typeof threadId !== "string" || !threadId)
    throw new Error("harness: AISDKTransport needs a threadId");

  const optionsRef = useRef(options);
  optionsRef.current = options;

  const [draft] = useStatewireState(
    (): Harness.State => ({
      threads: { [MAIN_NS]: { headId: null, status: "idle" } },
      status: "ready",
      runs: [],
    }),
  );
  const stateHost = getStateHost(draft);
  if (!stateHost) throw new Error("harness: state host missing");

  const [cell] = useState(() => ({
    source:
      options.initialState !== undefined
        ? structuredClone(options.initialState)
        : ({
            messages: {},
            headId: null,
            run: { phase: "idle" },
            queue: [],
            inbox: [],
          } satisfies AISDKTransport.State),
    listeners: new Set<() => void>(),
    overlay: [] as VoiceOverlay.Entry[],
    overlayVersion: 0,
    view: undefined as
      | { refs: readonly unknown[]; tree: ChatTree.Tree }
      | undefined,
    subagents: new Map<string, HarnessChat>(),
    activeTasks: new Set<string>(),
  }));

  const head = () => {
    const { headId, messages } = cell.source;
    return headId === null ? undefined : messages[headId]!.message;
  };

  // the overlay chains under the tree head; rebuilt when either changes
  const view = (): ChatTree.Tree => {
    const s = cell.source;
    const refs = [
      s.messages,
      Object.keys(s.messages).length,
      s.headId,
      cell.overlayVersion,
    ];
    if (cell.view && cell.view.refs.every((r, i) => Object.is(r, refs[i])))
      return cell.view.tree;
    const tree = overlaidView(s, cell.overlay);
    cell.view = { refs, tree };
    return tree;
  };
  const bump = () => void cell.overlayVersion++;

  const streamingOf = (chat: HarnessChat, tree: ChatTree.Tree) =>
    (chat.status === "submitted" || chat.status === "streaming") &&
    tree.headId !== null &&
    tree.messages[tree.headId]!.message.role === "assistant"
      ? [tree.headId]
      : [];

  const project = useProjection();
  const docs = useThreadDocuments({
    threadId,
    stateHost,
    read: () => {
      const s = cell.source;
      const streaming =
        s.run.phase === "active" && head()?.role === "assistant"
          ? [s.headId!]
          : [];
      const threads: Record<string, ThreadDocuments.ThreadView> = {};
      for (const [ns, tree] of Object.entries(s.subagents ?? {})) {
        const chat = cell.subagents.get(ns);
        threads[ns] = {
          ...tree,
          streamingIds: chat === undefined ? [] : streamingOf(chat, tree),
        };
      }
      return {
        ...view(),
        streamingIds: [...streaming, ...cell.activeTasks],
        threads,
      };
    },
  });

  const commit = () => {
    docs.touch();
    const s = cell.source;
    const entry = (() => {
      if (s.run.phase === "idle") return undefined;
      const inputRequests =
        s.run.phase === "suspended"
          ? pendingApprovals(head()).map((part) => ({
              id: part.approval.id,
              type: "tool-approval",
              toolCallId: part.toolCallId,
            }))
          : [];
      return {
        runId: s.run.runId,
        status:
          s.run.phase === "active"
            ? ("running" as const)
            : ("input-required" as const),
        queue: s.queue.map((item) => item.message),
        ...(inputRequests.length > 0 && { inputRequests }),
      };
    })();
    const threads: Record<string, Harness.ThreadState> = {
      [MAIN_NS]: {
        headId: view().headId,
        status:
          s.run.phase !== "active"
            ? "idle"
            : chat.status === "streaming"
              ? "streaming"
              : "submitted",
        ...(s.title !== undefined && { title: s.title }),
        ...(s.error !== undefined && { error: s.error }),
      },
    };
    for (const [ns, tree] of Object.entries(s.subagents ?? {})) {
      const status = cell.subagents.get(ns)?.status;
      threads[ns] = {
        headId: tree.headId,
        status:
          status === "streaming" || status === "submitted" ? status : "idle",
      };
    }
    project(draft, "threads", threads);
    project(draft, "status", entry?.status ?? "ready");
    project(draft, "runs", entry === undefined ? [] : [entry]);
    project(draft, "voice", voice.state());
    docs.refresh();
    for (const listener of [...cell.listeners]) listener();
  };

  const mutate = <T>(fn: (s: AISDKTransport.State) => T): T => {
    const result = fn(cell.source);
    commit();
    return result;
  };

  const [newChat] = useState(() => {
    const fallback = new DefaultChatTransport<UIMessage>();
    const current = () => optionsRef.current.transport ?? fallback;
    const { messageMetadataSchema, dataPartSchemas, onData } = options;
    return (id: string, tree: () => ChatTree.Tree) =>
      new HarnessChat({
        id,
        state: chatTreeState({ tree, onChange: commit }),
        transport: {
          sendMessages: (init) => current().sendMessages(init),
          reconnectToStream: (init) => current().reconnectToStream(init),
        },
        ...(messageMetadataSchema !== undefined && { messageMetadataSchema }),
        ...(dataPartSchemas !== undefined && { dataPartSchemas }),
        ...(onData !== undefined && { onData }),
      });
  });
  const [chat] = useState(() => newChat(threadId, () => cell.source));

  const subagent = (ns: string) => {
    let sub = cell.subagents.get(ns);
    if (sub === undefined) {
      const trees = (cell.source.subagents ??= {});
      trees[ns] ??= { messages: {}, headId: null };
      sub = newChat(`${threadId}/${ns}`, () => cell.source.subagents![ns]!);
      cell.subagents.set(ns, sub);
    }
    return sub;
  };

  const quiet = () => cell.source.run.phase === "idle";
  const deliver = () => {
    if (cell.overlay.some((entry) => entry.done)) {
      deliverOverlay(cell.source, cell.overlay);
      bump();
    }
  };

  const voice = useVoiceHost({
    factory: options.voice,
    onChange: () => commit(),
    host: {
      getVoiceSeed: () => voiceSeed(cell.source),
      upsertEphemeralMessage: (turn) => {
        upsertVoiceTurn(cell.source, cell.overlay, turn, true);
        bump();
        commit();
      },
      dropEphemeralMessage: (id) => {
        const at = cell.overlay.findIndex((entry) => entry.id === id);
        if (at === -1 && !cell.source.messages[id])
          throw new Error(`voice: message "${id}" is not in the thread`);
        if (at === -1 || cell.overlay[at]!.done) return;
        cell.overlay.splice(at, 1);
        bump();
        if (quiet()) deliver();
        commit();
      },
      commitVoiceTurns: (turns) => {
        for (const turn of turns)
          upsertVoiceTurn(cell.source, cell.overlay, turn, false);
        bump();
        if (quiet()) deliver();
        commit();
        return quiet() ? "committed" : "deferred";
      },
      delegate: async (taskId, text) => {
        const id = delegationId(taskId);
        const ns = delegationNs(taskId);
        if (
          cell.source.messages[id] !== undefined ||
          cell.overlay.some((entry) => entry.id === id)
        )
          throw new Error(`voice: task "${taskId}" was already delegated`);
        cell.activeTasks.add(id);
        cell.overlay.push(delegationEntry(taskId, text));
        bump();
        if (quiet()) deliver();
        commit();
        const settle = (output: string, error: boolean) => {
          const node = cell.source.messages[id];
          const entry = cell.overlay.find((e) => e.id === id);
          const target = node ?? entry;
          if (!target)
            throw new Error(`voice: task "${taskId}" left the thread`);
          target.message = settleDelegation(target.message, output, error);
          cell.activeTasks.delete(id);
          bump();
          commit();
        };
        const sub = subagent(ns);
        try {
          await sub.sendMessage(delegationTask(taskId, text));
          if (sub.status === "error")
            throw sub.error ?? new Error("chat error");
        } catch (error) {
          settle(error instanceof Error ? error.message : String(error), true);
          throw error;
        }
        const answer = trailingAssistantText(cell.source.subagents![ns]!, id);
        settle(answer, false);
        return answer;
      },
    },
  });

  const denyUnanswered = () => {
    const { headId } = cell.source;
    const message = head();
    if (headId === null || !message || pendingApprovals(message).length === 0)
      return;
    mutate((s) => {
      s.messages[headId]!.message = denyPending(message);
    });
  };

  const runTurn = async (cmd: Cmd, { signal, take }: RunHost.Context<Cmd>) => {
    if (cmd.kind === "input")
      throw new Error("harness: input command reached the run loop");
    const { run } = cell.source;
    if (run.phase === "idle")
      throw new Error("harness: run loop entered without a live run");
    const { runId } = run;
    const settled = () => {
      if (signal.aborted) throw abortError();
      if (chat.status === "error") throw chat.error ?? new Error("chat error");
    };
    const onAbort = () => void chat.stop();
    signal.addEventListener("abort", onAbort);
    try {
      if (cmd.kind === "send") {
        const { message } = cmd;
        await chat.sendMessage({
          ...toUIUserMessage(message.id, message.parts),
          ...(message.metadata !== undefined && { metadata: message.metadata }),
        });
        settled();
      } else if (cmd.kind === "reload") {
        await chat.regenerate();
        settled();
      } else if (pendingApprovals(head()).length === 0) {
        throw new Error("harness resume: the head has no pending approval");
      }
      while (pendingApprovals(head()).length > 0) {
        mutate((s) => {
          s.run = { phase: "suspended", runId };
        });
        const ids = new Set(pendingApprovals(head()).map((p) => p.approval.id));
        const next = await take(
          (c) => c.kind === "input" && ids.has(c.requestId),
        );
        if (next.kind !== "input")
          throw new Error("harness: non-input command reached input wait");
        await chat.addToolApprovalResponse({
          id: next.requestId,
          approved: next.decision === "approve",
        });
        if (pendingApprovals(head()).length > 0) continue;
        mutate((s) => {
          s.run = { phase: "active", runId };
          delete s.error;
        });
        await chat.sendMessage();
        settled();
      }
    } finally {
      signal.removeEventListener("abort", onAbort);
      denyUnanswered();
    }
  };

  const host = useRunHost<Cmd>({
    admission: (cmd, { running, suspended }) => {
      if (cmd.kind === "resume")
        throw new Error("harness: internal commands are not dispatchable");
      if (cmd.kind === "input")
        return running || cell.source.run.phase === "suspended"
          ? "deliver"
          : "drop";
      if (!running) return "start";
      if (suspended) return "preempt";
      return cmd.steer ? "preempt" : "enqueue";
    },
    onAdmit: (cmd) => {
      if (cmd.kind === "input" || cmd.kind === "resume") return;
      mutate((s) => {
        s.headId = cmd.parentId;
        s.run = { phase: "active", runId: cmd.runId };
        delete s.error;
        if (cmd.kind === "send" && s.title === undefined) {
          const text = cmd.message.parts
            .map((part) => (part.type === "text" ? part.text : ""))
            .join("")
            .trim();
          if (text) s.title = text.slice(0, 80);
        }
      });
    },
    run: runTurn,
    onEnqueue: (cmd) => {
      if (cmd.kind !== "send") return;
      mutate((s) => {
        const item = { message: cmd.message, parentId: cmd.parentId };
        const { insertAfter, insertBefore } = cmd.placement ?? {};
        const anchor = insertAfter ?? insertBefore;
        if (anchor === undefined) {
          s.queue.push(item);
          return;
        }
        const index = s.queue.findIndex((q) => q.message.id === anchor);
        if (index === -1)
          throw new Error(`harness: queue anchor "${anchor}" is not queued`);
        s.queue.splice(insertAfter !== undefined ? index + 1 : index, 0, item);
      });
    },
    dequeue: () => {
      const next = cell.source.queue[0];
      if (!next) return undefined;
      if (cell.source.run.phase === "idle")
        throw new Error("harness: dequeue without a run id");
      const { runId } = cell.source.run;
      mutate((s) => {
        s.queue = s.queue.filter((item) => item !== next);
      });
      return {
        kind: "send",
        message: next.message,
        parentId: next.parentId,
        steer: false,
        runId,
      };
    },
    onIdle: () =>
      mutate((s) => {
        s.run = { phase: "idle" };
        deliver();
      }),
    onError: (error) =>
      mutate((s) => {
        s.run = { phase: "idle" };
        s.error = error instanceof Error ? error.message : String(error);
        s.queue = [];
        deliver();
      }),
    buffer: {
      push: (cmd) => {
        if (cmd.kind === "resume")
          throw new Error("harness: internal commands are not deliverable");
        mutate((s) => {
          s.inbox.push(cmd);
        });
      },
      take: (predicate) => {
        const index = cell.source.inbox.findIndex(predicate);
        if (index === -1) return undefined;
        return mutate((s) => s.inbox.splice(index, 1)[0]!);
      },
      clear: () => {
        if (cell.source.inbox.length === 0) return;
        mutate((s) => {
          s.inbox = [];
        });
      },
    },
  });

  // launches are deferred so the dev-mode mount/cleanup/remount cycle cancels
  // the first schedule instead of aborting a live run
  useEffect(() => {
    let cancelled = false;
    const { phase } = cell.source.run;
    if (phase === "active") {
      denyUnanswered();
      mutate((s) => {
        s.run = { phase: "idle" };
        s.error = "run interrupted: the harness exited mid-stream";
        s.queue = [];
        s.inbox = [];
      });
    } else {
      commit();
    }
    if (cell.source.run.phase === "suspended")
      queueMicrotask(() => {
        if (!cancelled) host.resume({ kind: "resume" });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const commands = useStatewireCommands({
    ...runCommandHandlers({
      tree: () => cell.source,
      queue: () => cell.source.queue,
      setQueue: (queue) =>
        mutate((s) => {
          s.queue = queue;
        }),
      runId: () =>
        cell.source.run.phase === "idle" ? undefined : cell.source.run.runId,
      running: host.running,
      suspended: host.suspended,
      live: () => host.running() || cell.source.run.phase === "suspended",
      dispatch: host.dispatch,
      halt: host.halt,
      drain: host.drain,
      fail: (message) =>
        mutate((s) => {
          s.error = message;
        }),
    }),
    ...docs.handlers,
    ...voice.handlers,
    ...syncedDocument(CONTEXT_PROTOCOL),
  });

  return {
    state: draft,
    commands,
    get isBusy() {
      return cell.source.run.phase === "active";
    },
    documents: docs.documents,
    invoke: async (protocol, method, params) => {
      if (protocol === HARNESS_PROTOCOL.name) {
        const handler = (
          commands as Record<string, (...args: unknown[]) => Promise<unknown>>
        )[method];
        if (!handler) throw new Error(`harness: unknown command "${method}"`);
        return handler(...params);
      }
      if (protocol === INTEREST_PROTOCOL && method === "set")
        return docs.interestSet(docs.localAttach, params[0]);
      throw new Error(`harness: unknown command "${protocol}/${method}"`);
    },
    attaching: docs.attaching,
    detached: (attach) => {
      docs.detached(attach);
      voice.detached();
    },
    snapshot: () => structuredClone(cell.source),
    subscribe: (listener) => {
      cell.listeners.add(listener);
      return () => void cell.listeners.delete(listener);
    },
  };
};

/**
 * A harness transport that drives one AI SDK `Chat` per thread in-process:
 * `Chat` owns the request/stream cycle and its message list is the active
 * branch of the harness message tree. Plug the result into
 * `useHarness({ transport })`.
 *
 * The transport's durable state — message tree, run position, queue, inbox —
 * is `AISDKTransport.State`, readable via `snapshot()` / `subscribe()` and
 * restorable via `options.initialState`: a fresh mount over a restored
 * snapshot re-arms a suspended run's approval takes or finalizes one that
 * died mid-stream. The replicated `Harness.State` is a projection of it.
 */
export const AISDKTransport = resource(useAISDKTransport);

export namespace AISDKTransport {
  export type Options = {
    /** Keys the thread's documents on the wire; also the `Chat` id. */
    threadId: string;
    /** The AI SDK transport behind `Chat`; default `new DefaultChatTransport()` (`/api/chat`). Read live: the next request uses the current value. */
    transport?: ChatTransport<UIMessage>;
    /** A previously captured `snapshot()` (JSON-safe) to restore; the mounted transport resumes from its `run.phase`. */
    initialState?: State;
    /** Per-session voice provider factory; enables `voice/*` ([voice spec](/docs/spec/voice)). Absent: the commands reject `no-voice`. */
    voice?: VoiceHost.Factory | undefined;
  } & Pick<
    ChatInit<UIMessage>,
    "messageMetadataSchema" | "dataPartSchemas" | "onData"
  >;

  /** Durable run position. `runId` is the client-minted id of the live run. */
  export type RunState =
    | { phase: "idle" }
    | { phase: "active" | "suspended"; runId: string };

  /** The transport's durable source-of-truth state; plain JSON. */
  export type State = {
    /** Message tree: nodes keyed by message id, linked via `parentId` (`null` roots). */
    messages: Record<string, ThreadDocuments.Node>;
    /** Newest message on the active branch; `null` while empty. */
    headId: string | null;
    run: RunState;
    queue: RunCommands.QueueItem[];
    /** Delivered-but-unconsumed run commands (acked to the client, so they must survive a restart). */
    inbox: RunCommands.Command[];
    title?: string;
    error?: string;
    /** Voice delegation subagent trees keyed by namespace (`delegate:<taskId>`). */
    subagents?: Record<string, ChatTree.Tree>;
  };

  export type Instance = Statewire<Harness.State, Harness.Commands> & {
    /** Deep-cloned snapshot of the durable source state. */
    snapshot(): State;
    /** Notifies on every source-state commit. */
    subscribe(listener: () => void): () => void;
  };
}
