import { randomUUID } from "node:crypto";
import type { VoiceHost } from "../voice";

const BASE_URL = "https://api.openai.com/v1/live/sessions";
const WS_URL = "wss://api.openai.com/v1/live/sessions";
const DEFAULT_MODEL = "gpt-live-1";

// context appends are capped at 500 tokens each; ~4 chars/token leaves headroom
const CONTEXT_APPEND_MAX_CHARS = 1400;
const MAX_CONTEXT_APPEND_CHUNKS = 12;

const TRANSCRIPT_ROLES: Record<string, "user" | "assistant"> = {
  "session.input_transcript.delta": "user",
  "session.output_transcript.delta": "assistant",
};
const APPEND_EVENTS = {
  speakable: "session.commentary.append",
  commentary: "session.thinking.append",
  developer: "session.instructions.append",
};

/** Split text into append-sized chunks, preferring whitespace boundaries. */
export const chunkContextText = (input: string): string[] => {
  let text = input.trim();
  const chunks: string[] = [];
  while (text && chunks.length < MAX_CONTEXT_APPEND_CHUNKS) {
    if (text.length <= CONTEXT_APPEND_MAX_CHARS) {
      chunks.push(text);
      return chunks;
    }
    const half = CONTEXT_APPEND_MAX_CHARS / 2;
    const found = text.lastIndexOf(" ", CONTEXT_APPEND_MAX_CHARS);
    const splitAt = found >= half ? found : CONTEXT_APPEND_MAX_CHARS;
    chunks.push(text.slice(0, splitAt).trimEnd());
    text = text.slice(splitAt).trimStart();
  }
  if (text)
    console.warn(
      `gpt-live: context text truncated to ${MAX_CONTEXT_APPEND_CHUNKS} append chunks (${text.length} chars dropped)`,
    );
  return chunks;
};

const initialItem = (message: VoiceHost.SeedMessage) => ({
  type: "message",
  role: message.role,
  content: [
    {
      type: message.role === "assistant" ? "output_text" : "input_text",
      text: message.text,
    },
  ],
});

type Socket = {
  send(data: string): void;
  close(): void;
  on(event: "message", listener: (raw: { toString(): string }) => void): void;
  on(event: "close", listener: () => void): void;
  on(event: "error", listener: (error: Error) => void): void;
};

/**
 * One GPT Live session: WebRTC media negotiated up front through
 * `POST /v1/live/sessions`, control and events over the sideband WebSocket.
 * Wire shim for `VoiceHost.Factory`: `voice: () => gptLiveProvider({ apiKey })`.
 */
export const gptLiveProvider = (options: GptLive.Options): GptLive.Provider => {
  const { apiKey, model = DEFAULT_MODEL, instructions } = options;
  if (!apiKey) throw new Error("gpt-live: apiKey is required");
  const headers = { Authorization: `Bearer ${apiKey}` };

  let ws: Socket | null = null;
  let closed = false;
  let delegationId: string | null = null;
  const openTurns = new Map<"user" | "assistant", string>();
  const texts = new Map<string, string>();
  let userText = "";
  const provider: GptLive.Provider = {
    sessionId: null,
    start: async (offer, { seed, events }) => {
      const session: Record<string, unknown> = {
        model,
        delegation: { type: "client" },
        ...(instructions !== undefined && { instructions }),
        ...(seed.length > 0 && { input: seed.map(initialItem) }),
      };
      const response = await fetch(BASE_URL, {
        method: "POST",
        headers: { ...headers, "content-type": "application/json" },
        body: JSON.stringify({
          session,
          transport: { type: "webrtc", sdp: offer },
        }),
      });
      if (response.status !== 201)
        throw new Error(
          `gpt-live: session creation failed: ${response.status} ${await response.text()}`,
        );
      const created = (await response.json()) as {
        session: { id: string };
        transport: { sdp: string };
      };
      provider.sessionId = created.session.id;
      const { WebSocket } = await import("ws");
      const socket = new WebSocket(`${WS_URL}/${created.session.id}/attach`, {
        headers,
      });
      await new Promise<void>((resolve, reject) => {
        socket.once("open", resolve);
        socket.once("error", reject);
      });
      ws = socket;
      listen(socket, events);
      return created.transport.sdp;
    },
    // every append event of the public API requires `delegation_id`
    appendContext: async (text, channel) => {
      if (delegationId === null)
        throw new Error(
          `gpt-live: a ${channel} append needs a delegation in flight`,
        );
      for (const chunk of chunkContextText(text))
        send({
          type: APPEND_EVENTS[channel],
          delegation_id: delegationId,
          content: chunk,
        });
    },
    setInputPaused: async (paused) => {
      send({
        type: paused
          ? "session.input_audio.mute"
          : "session.input_audio.unmute",
      });
    },
    close: async () => {
      closed = true;
      const socket = ws;
      ws = null;
      if (socket === null) return;
      try {
        socket.send(JSON.stringify({ type: "session.close" }));
      } catch {
        // the transport may already be gone; close is best-effort
      }
      socket.close();
    },
  };

  const send = (event: Record<string, unknown>) => {
    if (ws === null) throw new Error("gpt-live: session is not started");
    ws.send(JSON.stringify(event));
  };

  const closeTurn = (events: VoiceHost.Events, role: "user" | "assistant") => {
    const turnId = openTurns.get(role)!;
    openTurns.delete(role);
    const text = texts.get(turnId)!;
    texts.delete(turnId);
    events.turnDone(turnId, text);
  };

  const transcriptDelta = (
    events: VoiceHost.Events,
    role: "user" | "assistant",
    delta: string,
  ) => {
    for (const other of [...openTurns.keys()])
      if (other !== role) closeTurn(events, other);
    let turnId = openTurns.get(role);
    if (turnId === undefined) {
      turnId = randomUUID().replaceAll("-", "");
      openTurns.set(role, turnId);
      texts.set(turnId, "");
      events.turnStarted(turnId, role);
    }
    const text = texts.get(turnId)! + delta;
    texts.set(turnId, text);
    if (role === "user") userText = text;
    events.turnDelta(turnId, delta);
  };

  const delegationCreated = (
    events: VoiceHost.Events,
    delegation: { id: string; target?: string },
  ) => {
    if (delegation.target !== "client") return;
    delegationId = delegation.id;
    if (!userText.trim()) {
      console.warn(
        `gpt-live: delegation ${delegation.id} arrived before any user transcript; ignored`,
      );
      return;
    }
    events.taskRequested(delegation.id, userText.trim());
  };

  let emitted = false;
  const emitClosed = (events: VoiceHost.Events, reason: string) => {
    if (emitted || closed) return;
    emitted = true;
    closed = true;
    events.closed(reason);
  };

  const listen = (socket: Socket, events: VoiceHost.Events) => {
    let reason = "connection-closed";
    socket.on("message", (raw) => {
      const event = JSON.parse(raw.toString()) as Record<string, unknown>;
      const kind = event["type"] as string;
      const role = TRANSCRIPT_ROLES[kind];
      if (role !== undefined)
        transcriptDelta(events, role, event["delta"] as string);
      // https://developers.openai.com/api/docs/guides/live-delegation: "session.delegation.created" carries no task text
      else if (kind === "session.delegation.created")
        delegationCreated(
          events,
          event["delegation"] as { id: string; target?: string },
        );
      else if (kind === "error")
        console.warn(
          `gpt-live: session ${provider.sessionId} error event`,
          event,
        );
      else if (kind === "session.closed") {
        reason = (event["reason"] as string | undefined) ?? "closed";
        socket.close();
      }
    });
    socket.on("error", (error) => {
      if (closed) return;
      console.error("gpt-live: sideband listener failed", error);
      reason = "listener-failed";
    });
    socket.on("close", () => {
      for (const role of [...openTurns.keys()]) closeTurn(events, role);
      emitClosed(events, reason);
    });
  };

  return provider;
};

export namespace GptLive {
  export type Options = {
    apiKey: string;
    /** Default `"gpt-live-1"`. */
    model?: string;
    instructions?: string;
  };
  export type Provider = VoiceHost.Provider & {
    /** Set once `start` created the session. */
    sessionId: string | null;
  };
}
