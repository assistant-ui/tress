import { AbstractChat } from "ai";
import type { ChatState, ChatStatus, UIMessage } from "ai";
import { chain } from "harness-sdk/host";
import type { ThreadDocuments } from "harness-sdk/ui-transport";

// Chat hands the same mutable message object to every write; the tree keeps
// plain JSON, so every stored message is a clone with explicit-undefined keys
// dropped
const toPlainJson = <T>(value: T): T =>
  value === undefined ? value : JSON.parse(JSON.stringify(value));

const nextSeq = (messages: Readonly<Record<string, ThreadDocuments.Node>>) =>
  Object.values(messages).reduce((max, node) => Math.max(max, node.seq), 0) + 1;

const splitMetadata = (message: UIMessage) => {
  const { metadata, ...rest } = message;
  if (
    metadata !== undefined &&
    (typeof metadata !== "object" ||
      metadata === null ||
      Array.isArray(metadata))
  )
    throw new Error(`chat tree: metadata of "${message.id}" must be an object`);
  return {
    message: toPlainJson(rest),
    metadata: toPlainJson(metadata as Record<string, unknown> | undefined),
  };
};

/** The active branch (root → head) of `tree` as AI SDK messages. */
export const activeBranch = (tree: ChatTree.Tree): UIMessage[] =>
  tree.headId === null
    ? []
    : chain({ messages: tree.messages, head: tree.headId }, tree.headId).map(
        (id) => {
          const node = tree.messages[id]!;
          return node.metadata === undefined
            ? node.message
            : { ...node.message, metadata: node.metadata };
        },
      );

/**
 * A `ChatState` whose message list is the active branch of a harness message
 * tree: pushes append under the head, replacements rewrite the addressed node,
 * truncation moves the head back along the branch. `status` and `error` are
 * ephemeral; `onChange` fires after every mutation.
 */
export const chatTreeState = (
  options: ChatTree.Options,
): ChatState<UIMessage> => {
  const { tree, onChange } = options;
  let status: ChatStatus = "ready";
  let error: Error | undefined;

  const branch = () =>
    tree().headId === null
      ? []
      : chain(
          { messages: tree().messages, head: tree().headId },
          tree().headId!,
        );

  const commit = <T>(fn: (t: ChatTree.Tree) => T): T => {
    const result = fn(tree());
    onChange();
    return result;
  };

  return {
    get status() {
      return status;
    },
    set status(next) {
      status = next;
      onChange();
    },
    get error() {
      return error;
    },
    set error(next) {
      error = next;
    },
    get messages() {
      return activeBranch(tree());
    },
    set messages(next) {
      const ids = branch();
      if (next.length > ids.length)
        throw new Error(
          "chat tree: only truncation of the active branch is supported",
        );
      next.forEach((message, index) => {
        if (message.id !== ids[index])
          throw new Error(
            `chat tree: message "${message.id}" is not on the active branch at ${index}`,
          );
      });
      commit((t) => {
        t.headId = ids[next.length - 1] ?? null;
      });
    },
    pushMessage: (message) => {
      if (tree().messages[message.id])
        throw new Error(`chat tree: message "${message.id}" already exists`);
      const stored = splitMetadata(message);
      commit((t) => {
        t.messages[message.id] = {
          parentId: t.headId,
          seq: nextSeq(t.messages),
          message: stored.message,
          ...(stored.metadata !== undefined && { metadata: stored.metadata }),
        };
        t.headId = message.id;
      });
    },
    popMessage: () => {
      const id = tree().headId;
      if (id === null) throw new Error("chat tree: pop on an empty branch");
      commit((t) => {
        t.headId = t.messages[id]!.parentId;
        delete t.messages[id];
      });
    },
    replaceMessage: (index, message) => {
      const id = branch()[index];
      if (id === undefined)
        throw new Error(
          `chat tree: no message at ${index} on the active branch`,
        );
      if (message.id !== id)
        throw new Error(
          `chat tree: replacing "${id}" with a different id "${message.id}"`,
        );
      const stored = splitMetadata(message);
      commit((t) => {
        const node = t.messages[id]!;
        node.message = stored.message;
        if (stored.metadata === undefined) delete node.metadata;
        else node.metadata = stored.metadata;
      });
    },
    snapshot: toPlainJson,
  };
};

/** `AbstractChat` over a `chatTreeState`; TypeScript needs the concrete subclass to construct one. */
export class HarnessChat extends AbstractChat<UIMessage> {}

export namespace ChatTree {
  /** Message tree keyed by id; `headId` names the active branch's newest message. */
  export type Tree = {
    messages: Record<string, ThreadDocuments.Node>;
    headId: string | null;
  };
  export type Options = {
    /** The live tree, mutated in place. */
    tree: () => Tree;
    onChange: () => void;
  };
}
