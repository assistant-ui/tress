import type { UIMessage } from "ai";
import { chain } from "harness-sdk/host";
import type { ThreadDocuments } from "harness-sdk/ui-transport";
import type { ChatTree } from "./chat-tree";
import type { VoiceHost } from "./voice";

export const VOICE_SOURCE = "voice";
export const DELEGATION_SOURCE = "voice_delegation";
export const DELEGATE_TOOL = "delegate";

export const delegationNs = (taskId: string) => `delegate:${taskId}`;
export const delegationId = (taskId: string) => `voicetask_${taskId}`;

/** The text parts of a message joined by blank lines. */
export const messageText = (message: UIMessage) =>
  message.parts
    .flatMap((part) => (part.type === "text" ? [part.text] : []))
    .join("\n\n")
    .trim();

const nextSeq = (messages: Readonly<Record<string, ThreadDocuments.Node>>) =>
  Object.values(messages).reduce((max, node) => Math.max(max, node.seq), 0) + 1;

const headChain = (tree: ChatTree.Tree) =>
  tree.headId === null
    ? []
    : chain({ messages: tree.messages, head: tree.headId }, tree.headId);

/** The main head chain as `{role, text}` seed messages; messages without text are skipped. */
export const voiceSeed = (tree: ChatTree.Tree): VoiceHost.SeedMessage[] =>
  headChain(tree).flatMap((id) => {
    const { message } = tree.messages[id]!;
    const text = messageText(message);
    return text ? [{ role: message.role, text }] : [];
  });

const turnMessage = (
  turn: VoiceHost.Turn,
  ephemeral: boolean,
): VoiceOverlay.Entry => ({
  id: turn.id,
  done: !ephemeral,
  message: {
    id: turn.id,
    role: turn.role,
    parts: [
      {
        type: "text",
        text: turn.text,
        state: ephemeral ? "streaming" : "done",
      },
    ],
  },
  metadata: { source: VOICE_SOURCE, ...(ephemeral && { ephemeral: true }) },
});

/** Messages that sit after the tree head until the run is quiet: in-flight voice turns and journaled commits. */
export namespace VoiceOverlay {
  export type Entry = {
    id: string;
    /** Journaled: survives a drop and lands in the tree on the next delivery. */
    done: boolean;
    message: UIMessage;
    metadata: Record<string, unknown>;
  };
}

/** The tree with the overlay chained under its head. */
export const overlaidView = (
  tree: ChatTree.Tree,
  overlay: readonly VoiceOverlay.Entry[],
): ChatTree.Tree => {
  if (overlay.length === 0) return tree;
  const messages = { ...tree.messages };
  let parentId = tree.headId;
  let seq = nextSeq(tree.messages);
  for (const entry of overlay) {
    messages[entry.id] = {
      parentId,
      seq: seq++,
      message: entry.message,
      metadata: entry.metadata,
    };
    parentId = entry.id;
  }
  return { messages, headId: parentId };
};

/** Write a turn at the head or update the one under its id in place. */
export const upsertVoiceTurn = (
  tree: ChatTree.Tree,
  overlay: VoiceOverlay.Entry[],
  turn: VoiceHost.Turn,
  ephemeral: boolean,
) => {
  const next = turnMessage(turn, ephemeral);
  const entry = overlay.find((e) => e.id === turn.id);
  const node = tree.messages[turn.id];
  const role = entry?.message.role ?? node?.message.role;
  if (role !== undefined && role !== turn.role)
    throw new Error(
      `voice: turn "${turn.id}" is a ${role} message, not ${turn.role}`,
    );
  if (entry) {
    Object.assign(entry, next);
    return;
  }
  if (node) {
    node.message = next.message;
    node.metadata = next.metadata;
    return;
  }
  overlay.push(next);
};

/** Move the leading journaled overlay entries into the tree under its head; an in-flight turn holds back everything after it. */
export const deliverOverlay = (
  tree: ChatTree.Tree,
  overlay: VoiceOverlay.Entry[],
) => {
  let delivered = 0;
  for (const entry of overlay) {
    if (!entry.done) break;
    tree.messages[entry.id] = {
      parentId: tree.headId,
      seq: nextSeq(tree.messages),
      message: entry.message,
      metadata: entry.metadata,
    };
    tree.headId = entry.id;
    delivered++;
  }
  overlay.splice(0, delivered);
};

/** The main-thread assistant message carrying the delegation's tool part. */
export const delegationEntry = (
  taskId: string,
  text: string,
): VoiceOverlay.Entry => ({
  id: delegationId(taskId),
  done: true,
  message: {
    id: delegationId(taskId),
    role: "assistant",
    parts: [
      {
        type: "dynamic-tool",
        toolName: DELEGATE_TOOL,
        toolCallId: taskId,
        state: "input-available",
        input: { text },
        toolMetadata: { ns: delegationNs(taskId) },
      },
    ],
  },
  metadata: { source: DELEGATION_SOURCE },
});

/** The user message the task text runs as in the delegation namespace. */
export const delegationTask = (taskId: string, text: string): UIMessage => ({
  id: delegationId(taskId),
  role: "user",
  parts: [{ type: "text", text }],
  metadata: { source: DELEGATION_SOURCE },
});

export const settleDelegation = (
  message: UIMessage,
  output: string,
  error: boolean,
): UIMessage => {
  const part = message.parts[0];
  if (part?.type !== "dynamic-tool")
    throw new Error(`voice: "${message.id}" carries no delegate part`);
  const settled = {
    type: "dynamic-tool" as const,
    toolName: part.toolName,
    toolCallId: part.toolCallId,
    input: part.input,
    ...(part.toolMetadata !== undefined && { toolMetadata: part.toolMetadata }),
  };
  return {
    ...message,
    parts: [
      error
        ? { ...settled, state: "output-error", errorText: output }
        : { ...settled, state: "output-available", output },
    ],
  };
};

/** The assistant text on the head chain after `afterId`; voice turns are skipped. */
export const trailingAssistantText = (
  tree: ChatTree.Tree,
  afterId: string,
): string => {
  const ids = headChain(tree);
  const at = ids.indexOf(afterId);
  if (at === -1) return "";
  return ids
    .slice(at + 1)
    .flatMap((id) => {
      const node = tree.messages[id]!;
      if (
        node.message.role !== "assistant" ||
        node.metadata?.["source"] === VOICE_SOURCE
      )
        return [];
      const text = messageText(node.message);
      return text ? [text] : [];
    })
    .join("\n\n");
};
