# @harness-sdk/ai-sdk

Runs the harness state machine in your process over the AI SDK's `Chat`: one `Chat` per thread against a UI message stream endpoint, its message list the active branch of the harness message tree. Part of [harness-sdk](https://github.com/assistant-ui/harness-sdk), with `statewire` and `pinned`.

## Install

```sh
pnpm add @harness-sdk/ai-sdk harness-sdk ai react
```

## Use

```tsx
import { DefaultChatTransport } from "ai";
import { useHarness } from "harness-sdk";
import { AISDKTransport } from "@harness-sdk/ai-sdk";

export const App = () => {
  const harness = useHarness({
    transport: AISDKTransport({
      threadId: "main",
      transport: new DefaultChatTransport({ api: "/api/chat" }),
    }),
  });
  return (
    <div>
      {harness.messages.map((m) => (
        <p key={m.id}>{m.role}</p>
      ))}
      <button onClick={() => harness.sendMessage("hi")}>send</button>
    </div>
  );
};
```

## Docs

- Get started: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/get-started/in-process/page.mdx
- Guide: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/guides/harness/transports/page.mdx
- Reference: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/reference/harness-sdk-host/page.mdx
- Spec: https://github.com/assistant-ui/harness-sdk/blob/main/apps/docs/app/docs/spec/runs-protocol/page.mdx
